/**
 * Landing FAQ + call-to-action dictionary (namespace `q`).
 * Five FAQ groups: channels, mini apps, deposits, withdrawals, CPM.
 * English is the source of truth; fr/ru/zh mirror it key for key.
 */

type Item = { q: string; a: string };
type Group = { label: string; items: Item[] };

type Q = {
  cta: {
    tag: string;
    title: string;
    sub: string;
    advTag: string;
    advTitle: string;
    advDesc: string;
    advBtn: string;
    advAlt: string;
    pubTag: string;
    pubTitle: string;
    pubDesc: string;
    pubBtn: string;
    pubAlt: string;
    tgTitle: string;
    tgDesc: string;
    tgBot: string;
    tgChannel: string;
  };
  faq: {
    tag: string;
    title: string;
    sub: string;
    all: string;
    more: string;
    moreBtn: string;
    groups: Group[];
  };
};

const en: Q = {
  cta: {
    tag: "Get started",
    title: "Two dashboards, one network",
    sub: "Advertisers launch native Telegram campaigns in minutes. Publishers connect a channel or Mini App and get paid in USDT.",
    advTag: "For advertisers",
    advTitle: "Launch your first campaign",
    advDesc: "Set a budget, pick countries and languages, upload your creative and go live from a $1.70 CPM.",
    advBtn: "Open the advertiser dashboard",
    advAlt: "Fund a balance in crypto or fiat",
    pubTag: "For publishers",
    pubTitle: "Monetize your audience",
    pubDesc: "Add your Telegram channel or Mini App, choose how many ads run per day and track earnings live.",
    pubBtn: "Open the publisher dashboard",
    pubAlt: "Request a withdrawal from 50 USDT",
    tgTitle: "Do it inside Telegram",
    tgDesc: "Talk to our team, get your channel reviewed or your SDK key issued without leaving the app.",
    tgBot: "Chat with the AdsKinz bot",
    tgChannel: "Follow the AdsKinz channel",
  },
  faq: {
    tag: "Everything explained",
    title: "Frequently asked questions",
    sub: "Channels, Mini Apps, deposits, withdrawals and the minimum CPM — the long answers, in one place.",
    all: "All topics",
    more: "Still unsure about something?",
    moreBtn: "Ask us on Telegram",
    groups: [
      {
        label: "Telegram channels",
        items: [
          {
            q: "How do I connect my Telegram channel?",
            a: "Add your channel name and public t.me link in the publisher dashboard, then add our bot as an administrator with permission to post. Review usually takes less than one business day.",
          },
          {
            q: "Is there a minimum number of subscribers?",
            a: "No hard threshold. Channels with real, active subscribers are approved; recycled or bot-inflated audiences are rejected by our anti-fraud scoring.",
          },
          {
            q: "How many ads will be posted in my channel?",
            a: "You decide: 0 to 3 native posts per day, with the time slots of your choice. Nothing is ever published outside the frequency you set.",
          },
          {
            q: "Can I refuse an advertiser?",
            a: "Yes. Every placement can be paused instantly, and you can reject a campaign that does not fit your audience without affecting your account standing.",
          },
        ],
      },
      {
        label: "Mini Apps & bots",
        items: [
          {
            q: "What do I need to connect a Mini App?",
            a: "The app name, the direct link (https://t.me/MyTgBot/app), the original web URL and your bot ID. You then receive a Kinz-ID key to paste into the SDK.",
          },
          {
            q: "Which ad formats are available in Mini Apps?",
            a: "Interstitial and pop formats, both rendered natively inside your app. You can enable one or both, and disable them at any time.",
          },
          {
            q: "How long does the SDK integration take?",
            a: "A few minutes: one script, one key, one call at the moment you want an ad shown. No build pipeline changes and no external accounts.",
          },
          {
            q: "Do Mini Apps need a subscriber threshold?",
            a: "No. Mini Apps and bots are accepted on traffic quality alone, so a young app with engaged users can start earning right away.",
          },
        ],
      },
      {
        label: "Deposits",
        items: [
          {
            q: "How do I fund my advertiser balance?",
            a: "By crypto (USDT on TRC20 and TON, plus major networks) or by card and bank transfer in fiat. Crypto deposits are credited after network confirmation.",
          },
          {
            q: "Is there a minimum deposit?",
            a: "Campaigns need a budget of at least 50 USDT to run, so a first deposit of 50 USDT or more is recommended. Smaller budgets are flagged in the campaign form.",
          },
          {
            q: "Can I get a refund of an unspent budget?",
            a: "Yes. Unspent budget stays on your balance and can be moved to another campaign at any time, or refunded to the original payment method on request.",
          },
        ],
      },
      {
        label: "Withdrawals",
        items: [
          {
            q: "What is the minimum payout?",
            a: "50 USDT. Below that, earnings simply accumulate on your available balance until you cross the threshold.",
          },
          {
            q: "Which networks can I withdraw to?",
            a: "TRC20 (TRON) and TON. Always double-check the network of the address you paste — a TRC20 payout sent to a non-TRC20 address cannot be recovered.",
          },
          {
            q: "How long does a withdrawal take?",
            a: "Requests are reviewed and paid within one business day in most cases. You can follow each request through Requested, Approved and Paid, with the transaction hash attached.",
          },
          {
            q: "Are there withdrawal fees?",
            a: "No AdsKinz fee. Only the network fee of the chain you choose applies, which is why TON and TRC20 are our two supported rails.",
          },
        ],
      },
      {
        label: "Minimum CPM & pricing",
        items: [
          {
            q: "What is the minimum CPM?",
            a: "$1.70 per thousand impressions. That is the floor advertisers can bid, and the base against which publisher earnings are calculated.",
          },
          {
            q: "Can I bid higher than the minimum?",
            a: "Yes, and higher bids win better placements. Premium channels and high-intent geos usually clear well above the floor.",
          },
          {
            q: "How are publisher earnings calculated?",
            a: "Per validated impression, at the CPM of the winning campaign. Fraudulent or duplicated impressions are removed before earnings are credited.",
          },
        ],
      },
    ],
  },
};

const fr: Q = {
  cta: {
    tag: "Commencer",
    title: "Deux espaces, un seul réseau",
    sub: "Les annonceurs lancent des campagnes natives en quelques minutes. Les éditeurs connectent un canal ou une Mini App et sont payés en USDT.",
    advTag: "Pour les annonceurs",
    advTitle: "Lancez votre première campagne",
    advDesc: "Définissez un budget, choisissez pays et langues, importez votre visuel et diffusez à partir de 1,70 $ de CPM.",
    advBtn: "Ouvrir l'espace annonceur",
    advAlt: "Alimenter un solde en crypto ou en fiat",
    pubTag: "Pour les éditeurs",
    pubTitle: "Monétisez votre audience",
    pubDesc: "Ajoutez votre canal Telegram ou votre Mini App, choisissez le nombre de pubs par jour et suivez vos gains en direct.",
    pubBtn: "Ouvrir l'espace éditeur",
    pubAlt: "Demander un retrait dès 50 USDT",
    tgTitle: "Faites-le dans Telegram",
    tgDesc: "Parlez à notre équipe, faites vérifier votre canal ou obtenez votre clé SDK sans quitter l'application.",
    tgBot: "Discuter avec le bot AdsKinz",
    tgChannel: "Suivre le canal AdsKinz",
  },
  faq: {
    tag: "Tout est expliqué",
    title: "Questions fréquentes",
    sub: "Canaux, Mini Apps, dépôts, retraits et CPM minimum — les réponses détaillées, au même endroit.",
    all: "Tous les sujets",
    more: "Une question sans réponse ?",
    moreBtn: "Écrivez-nous sur Telegram",
    groups: [
      {
        label: "Canaux Telegram",
        items: [
          {
            q: "Comment connecter mon canal Telegram ?",
            a: "Ajoutez le nom du canal et son lien public t.me dans l'espace éditeur, puis ajoutez notre bot comme administrateur avec le droit de publier. La vérification prend en général moins d'un jour ouvré.",
          },
          {
            q: "Y a-t-il un nombre minimum d'abonnés ?",
            a: "Aucun seuil strict. Les canaux avec de vrais abonnés actifs sont approuvés ; les audiences recyclées ou gonflées par des bots sont rejetées par notre scoring anti-fraude.",
          },
          {
            q: "Combien de pubs seront publiées dans mon canal ?",
            a: "C'est vous qui décidez : de 0 à 3 publications natives par jour, aux créneaux de votre choix. Rien n'est publié en dehors de la fréquence que vous fixez.",
          },
          {
            q: "Puis-je refuser un annonceur ?",
            a: "Oui. Chaque emplacement peut être mis en pause immédiatement et vous pouvez refuser une campagne qui ne correspond pas à votre audience, sans impact sur votre compte.",
          },
        ],
      },
      {
        label: "Mini Apps et bots",
        items: [
          {
            q: "Que faut-il pour connecter une Mini App ?",
            a: "Le nom de l'app, le lien direct (https://t.me/MyTgBot/app), l'URL web d'origine et l'ID de votre bot. Vous recevez ensuite une clé Kinz-ID à coller dans le SDK.",
          },
          {
            q: "Quels formats sont disponibles dans les Mini Apps ?",
            a: "Les formats interstitiel et pop, affichés nativement dans votre app. Vous pouvez en activer un ou les deux, et les désactiver à tout moment.",
          },
          {
            q: "Combien de temps prend l'intégration du SDK ?",
            a: "Quelques minutes : un script, une clé, un appel au moment où vous voulez afficher une pub. Aucun changement de build ni compte externe.",
          },
          {
            q: "Faut-il un seuil d'abonnés pour une Mini App ?",
            a: "Non. Les Mini Apps et bots sont acceptés sur la seule qualité du trafic : une app récente avec des utilisateurs engagés peut gagner tout de suite.",
          },
        ],
      },
      {
        label: "Dépôts",
        items: [
          {
            q: "Comment alimenter mon solde annonceur ?",
            a: "En crypto (USDT sur TRC20 et TON, plus les grands réseaux) ou en fiat par carte et virement. Les dépôts crypto sont crédités après confirmation du réseau.",
          },
          {
            q: "Y a-t-il un dépôt minimum ?",
            a: "Une campagne doit disposer d'au moins 50 USDT de budget, donc un premier dépôt de 50 USDT ou plus est conseillé. Les budgets inférieurs sont signalés dans le formulaire.",
          },
          {
            q: "Puis-je récupérer un budget non dépensé ?",
            a: "Oui. Le budget non dépensé reste sur votre solde et peut être basculé sur une autre campagne à tout moment, ou remboursé sur le moyen de paiement d'origine sur demande.",
          },
        ],
      },
      {
        label: "Retraits",
        items: [
          {
            q: "Quel est le retrait minimum ?",
            a: "50 USDT. En dessous, les gains s'accumulent simplement sur votre solde disponible jusqu'au seuil.",
          },
          {
            q: "Vers quels réseaux puis-je retirer ?",
            a: "TRC20 (TRON) et TON. Vérifiez toujours le réseau de l'adresse collée : un paiement TRC20 envoyé vers une adresse non TRC20 est irrécupérable.",
          },
          {
            q: "Combien de temps prend un retrait ?",
            a: "Les demandes sont vérifiées et payées sous un jour ouvré dans la plupart des cas. Vous suivez chaque demande de Demandé à Approuvé puis Payé, avec le hash de transaction.",
          },
          {
            q: "Y a-t-il des frais de retrait ?",
            a: "Aucun frais AdsKinz. Seuls les frais réseau de la chaîne choisie s'appliquent : c'est pour cela que nous avons retenu TON et TRC20.",
          },
        ],
      },
      {
        label: "CPM minimum et tarifs",
        items: [
          {
            q: "Quel est le CPM minimum ?",
            a: "1,70 $ pour mille impressions. C'est le plancher d'enchère des annonceurs et la base de calcul des gains éditeurs.",
          },
          {
            q: "Puis-je enchérir au-dessus du minimum ?",
            a: "Oui, et les enchères plus élevées obtiennent les meilleurs emplacements. Les canaux premium et les zones à forte intention dépassent largement le plancher.",
          },
          {
            q: "Comment sont calculés les gains éditeurs ?",
            a: "Par impression validée, au CPM de la campagne gagnante. Les impressions frauduleuses ou dupliquées sont retirées avant le crédit des gains.",
          },
        ],
      },
    ],
  },
};

const ru: Q = {
  cta: {
    tag: "Начать",
    title: "Два кабинета, одна сеть",
    sub: "Рекламодатели запускают нативные кампании за минуты. Паблишеры подключают канал или Mini App и получают выплаты в USDT.",
    advTag: "Рекламодателям",
    advTitle: "Запустите первую кампанию",
    advDesc: "Задайте бюджет, выберите страны и языки, загрузите креатив и стартуйте от CPM $1.70.",
    advBtn: "Открыть кабинет рекламодателя",
    advAlt: "Пополнить баланс криптой или фиатом",
    pubTag: "Паблишерам",
    pubTitle: "Монетизируйте аудиторию",
    pubDesc: "Добавьте канал Telegram или Mini App, выберите число реклам в день и следите за доходом в реальном времени.",
    pubBtn: "Открыть кабинет паблишера",
    pubAlt: "Запросить вывод от 50 USDT",
    tgTitle: "Всё прямо в Telegram",
    tgDesc: "Свяжитесь с командой, отправьте канал на проверку или получите ключ SDK, не выходя из приложения.",
    tgBot: "Написать боту AdsKinz",
    tgChannel: "Подписаться на канал AdsKinz",
  },
  faq: {
    tag: "Полные ответы",
    title: "Частые вопросы",
    sub: "Каналы, Mini Apps, пополнения, выводы и минимальный CPM — подробные ответы в одном месте.",
    all: "Все темы",
    more: "Остался вопрос?",
    moreBtn: "Спросите в Telegram",
    groups: [
      {
        label: "Telegram-каналы",
        items: [
          {
            q: "Как подключить свой канал?",
            a: "Укажите название канала и публичную ссылку t.me в кабинете паблишера, затем добавьте нашего бота администратором с правом публикации. Проверка обычно занимает меньше одного рабочего дня.",
          },
          {
            q: "Есть ли минимум подписчиков?",
            a: "Жёсткого порога нет. Каналы с реальными активными подписчиками проходят модерацию; накрученные аудитории отклоняются антифрод-скорингом.",
          },
          {
            q: "Сколько реклам выйдет в моём канале?",
            a: "Решаете вы: от 0 до 3 нативных постов в день в выбранные вами слоты. Ничего не публикуется сверх заданной частоты.",
          },
          {
            q: "Могу ли я отказать рекламодателю?",
            a: "Да. Любое место можно мгновенно поставить на паузу, а неподходящую кампанию отклонить без последствий для аккаунта.",
          },
        ],
      },
      {
        label: "Mini Apps и боты",
        items: [
          {
            q: "Что нужно для подключения Mini App?",
            a: "Название приложения, прямая ссылка (https://t.me/MyTgBot/app), исходный веб-URL и ID бота. Затем вы получаете ключ Kinz-ID для SDK.",
          },
          {
            q: "Какие форматы доступны в Mini Apps?",
            a: "Interstitial и pop, отрисованные нативно внутри приложения. Можно включить один или оба и отключить в любой момент.",
          },
          {
            q: "Сколько занимает интеграция SDK?",
            a: "Несколько минут: один скрипт, один ключ, один вызов в момент показа рекламы. Без изменений сборки и внешних аккаунтов.",
          },
          {
            q: "Нужен ли порог по аудитории для Mini App?",
            a: "Нет. Mini Apps и боты принимаются по качеству трафика, поэтому молодое приложение с активными пользователями зарабатывает сразу.",
          },
        ],
      },
      {
        label: "Пополнения",
        items: [
          {
            q: "Как пополнить баланс рекламодателя?",
            a: "Криптой (USDT в сетях TRC20 и TON и другие основные сети) или фиатом — картой и банковским переводом. Крипто зачисляется после подтверждения сети.",
          },
          {
            q: "Есть ли минимальное пополнение?",
            a: "Кампании нужен бюджет от 50 USDT, поэтому первое пополнение от 50 USDT предпочтительно. Меньшие бюджеты подсвечиваются в форме кампании.",
          },
          {
            q: "Можно ли вернуть неизрасходованный бюджет?",
            a: "Да. Остаток остаётся на балансе, его можно перенести в другую кампанию в любой момент или вернуть на исходный способ оплаты по запросу.",
          },
        ],
      },
      {
        label: "Выводы",
        items: [
          {
            q: "Какая минимальная выплата?",
            a: "50 USDT. Ниже порога доход просто накапливается на доступном балансе.",
          },
          {
            q: "В какие сети можно выводить?",
            a: "TRC20 (TRON) и TON. Всегда проверяйте сеть адреса: выплата TRC20 на адрес другой сети не восстанавливается.",
          },
          {
            q: "Сколько идёт вывод?",
            a: "В большинстве случаев заявки проверяются и оплачиваются в течение одного рабочего дня. Статусы: Запрошено, Одобрено, Выплачено — с хэшем транзакции.",
          },
          {
            q: "Есть ли комиссия за вывод?",
            a: "Комиссии AdsKinz нет. Применяется только сетевая комиссия выбранной сети — поэтому мы поддерживаем именно TON и TRC20.",
          },
        ],
      },
      {
        label: "Минимальный CPM и цены",
        items: [
          {
            q: "Каков минимальный CPM?",
            a: "$1.70 за тысячу показов. Это нижняя граница ставки рекламодателя и база расчёта дохода паблишера.",
          },
          {
            q: "Можно ли ставить выше минимума?",
            a: "Да, более высокие ставки получают лучшие размещения. Премиальные каналы и целевые гео обычно идут заметно выше порога.",
          },
          {
            q: "Как считается доход паблишера?",
            a: "За каждый валидный показ по CPM победившей кампании. Фрод и дубли удаляются до начисления.",
          },
        ],
      },
    ],
  },
};

const zh: Q = {
  cta: {
    tag: "开始使用",
    title: "两个后台，一个网络",
    sub: "广告主几分钟内即可投放原生广告；发布者接入频道或小程序，用 USDT 收款。",
    advTag: "广告主",
    advTitle: "投放你的第一个广告",
    advDesc: "设定预算、选择国家与语言、上传素材，最低 $1.70 CPM 起投。",
    advBtn: "进入广告主后台",
    advAlt: "使用加密货币或法币充值",
    pubTag: "发布者",
    pubTitle: "让你的流量变现",
    pubDesc: "添加 Telegram 频道或小程序，自定义每日广告条数，实时查看收益。",
    pubBtn: "进入发布者后台",
    pubAlt: "满 50 USDT 即可提现",
    tgTitle: "全部在 Telegram 内完成",
    tgDesc: "联系团队、提交频道审核或获取 SDK 密钥，无需离开应用。",
    tgBot: "与 AdsKinz 机器人对话",
    tgChannel: "关注 AdsKinz 频道",
  },
  faq: {
    tag: "详尽解答",
    title: "常见问题",
    sub: "频道、小程序、充值、提现与最低 CPM——完整答案都在这里。",
    all: "全部主题",
    more: "还有疑问？",
    moreBtn: "在 Telegram 上咨询",
    groups: [
      {
        label: "Telegram 频道",
        items: [
          {
            q: "如何接入我的频道？",
            a: "在发布者后台填写频道名称与公开 t.me 链接，然后将我们的机器人设为管理员并授予发布权限。审核通常不超过一个工作日。",
          },
          {
            q: "有订阅者数量门槛吗？",
            a: "没有硬性门槛。拥有真实活跃订阅者的频道会通过审核；刷量或机器人虚增的受众将被反欺诈评分拒绝。",
          },
          {
            q: "我的频道每天会发几条广告？",
            a: "由你决定：每天 0 到 3 条原生贴文，时段自选。绝不会超出你设定的频率。",
          },
          {
            q: "我可以拒绝某个广告主吗？",
            a: "可以。任何广告位都能立即暂停，不合适的活动可以直接拒绝，不影响账户状态。",
          },
        ],
      },
      {
        label: "小程序与机器人",
        items: [
          {
            q: "接入小程序需要什么？",
            a: "应用名称、直达链接（https://t.me/MyTgBot/app）、原始网页地址和机器人 ID。随后你会获得用于 SDK 的 Kinz-ID 密钥。",
          },
          {
            q: "小程序支持哪些广告格式？",
            a: "插屏与弹出格式，均在应用内原生呈现。可任选其一或同时启用，也可随时关闭。",
          },
          {
            q: "SDK 接入需要多久？",
            a: "几分钟：一个脚本、一个密钥、一次调用。无需修改构建流程，也无需外部账号。",
          },
          {
            q: "小程序有受众门槛吗？",
            a: "没有。小程序与机器人只看流量质量，新上线但用户活跃的应用可以立即开始赚钱。",
          },
        ],
      },
      {
        label: "充值",
        items: [
          {
            q: "如何为广告主余额充值？",
            a: "支持加密货币（TRC20 与 TON 上的 USDT 及主流网络）以及银行卡、电汇等法币方式。加密充值在网络确认后入账。",
          },
          {
            q: "有最低充值金额吗？",
            a: "活动预算至少 50 USDT，因此建议首充 50 USDT 以上。低于该金额会在活动表单中提示。",
          },
          {
            q: "未花完的预算能退吗？",
            a: "可以。剩余预算保留在余额中，可随时转到其他活动，也可申请原路退回。",
          },
        ],
      },
      {
        label: "提现",
        items: [
          {
            q: "最低提现金额是多少？",
            a: "50 USDT。未达门槛时，收益会持续累计在可用余额中。",
          },
          {
            q: "可以提现到哪些网络？",
            a: "TRC20（TRON）与 TON。请务必核对地址所属网络：TRC20 提现发送到非 TRC20 地址将无法找回。",
          },
          {
            q: "提现需要多久？",
            a: "多数情况下一个工作日内完成审核与打款。你可以跟踪「已申请、已批准、已支付」三个状态，并查看交易哈希。",
          },
          {
            q: "提现有手续费吗？",
            a: "AdsKinz 不收费，仅收取所选链的网络费——这正是我们只支持 TON 与 TRC20 的原因。",
          },
        ],
      },
      {
        label: "最低 CPM 与定价",
        items: [
          {
            q: "最低 CPM 是多少？",
            a: "每千次展示 $1.70。这是广告主的出价下限，也是发布者收益的计算基准。",
          },
          {
            q: "可以出价高于最低值吗？",
            a: "可以，出价越高越容易获得优质展示位。优质频道与高意向地区通常远高于下限。",
          },
          {
            q: "发布者收益如何计算？",
            a: "按有效展示乘以中标活动的 CPM 计算。欺诈与重复展示会在结算前剔除。",
          },
        ],
      },
    ],
  },
};

export const faqDict = {
  en: { q: en },
  fr: { q: fr },
  ru: { q: ru },
  zh: { q: zh },
};

/** Flat English Q/A pairs, used to emit FAQPage JSON-LD for search engines. */
export const faqJsonLd = en.faq.groups.flatMap((g) => g.items);
