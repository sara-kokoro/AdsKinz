/**
 * Landing v2 dictionary (namespace `x`): hero, monetization story,
 * advertiser story, money rails (deposits / withdrawals / CPM floor),
 * testimonials, support and footer. Four languages, same shape.
 */

type Q = { r: string; q: string };

type X = {
  hero: {
    badge: string;
    t1: string;
    accent: string;
    t2: string;
    sub: string;
    ctaAdv: string;
    ctaPub: string;
    note: string;
  };
  kpi: { imp: string; chan: string; apps: string; paid: string; cpm: string };
  monet: {
    tag: string;
    title: string;
    sub: string;
    c1t: string;
    c1d: string;
    c2t: string;
    c2d: string;
    c3t: string;
    c3d: string;
    b1: string;
    b2: string;
    b3: string;
    b4: string;
    cta: string;
  };
  adv: {
    tag: string;
    title: string;
    sub: string;
    b1: string;
    b2: string;
    b3: string;
    b4: string;
    cta: string;
  };
  money: {
    title: string;
    sub: string;
    depT: string;
    depCrypto: string;
    depCryptoD: string;
    depFiat: string;
    depFiatD: string;
    wdT: string;
    wdMin: string;
    wdMinD: string;
    wdNet: string;
    wdNetD: string;
    cpmT: string;
    cpmD: string;
    floor: string;
  };
  test: { title: string; sub: string; items: Q[] };
  support: { title: string; sub: string; mailT: string; botT: string; botD: string; mailD: string; hours: string };
  cta: { title: string; sub: string; btn: string; btn2: string };
  foot: { blurb: string; powered: string; created: string; rights: string; product: string; company: string; support: string };
};

const names = ["Kwame A.", "Mei L.", "Anders V.", "Lucía R.", "Rohit S.", "Amina D.", "Pavel K."];

const en: X = {
  hero: {
    badge: "Native advertising built for Telegram",
    t1: "Monetize your channel and Mini App.",
    accent: "Grow your business",
    t2: "with ads that feel native.",
    sub: "AdsKinz connects Telegram publishers with advertisers. Publishers earn in USDT on every real impression. Advertisers reach millions of users inside channels and Mini Apps, from a $1.70 CPM.",
    ctaAdv: "Advertise on AdsKinz",
    ctaPub: "Monetize my traffic",
    note: "No setup fee · Minimum payout 50 USDT · TRC20 & TON",
  },
  kpi: { imp: "Monthly impressions", chan: "Connected channels", apps: "Mini Apps", paid: "Paid to publishers", cpm: "Minimum CPM" },
  monet: {
    tag: "For publishers",
    title: "Turn your Telegram audience into monthly revenue",
    sub: "Connect a channel, a bot or a Mini App once. Ads are matched to your language, delivered natively, and paid in USDT.",
    c1t: "Channels",
    c1d: "Native sponsored posts published in your feed. You keep full control of frequency — up to 3 posts a day.",
    c2t: "Mini Apps",
    c2d: "Full-screen interstitials between two user actions, integrated with the Kinz-ID SDK in a few lines of code.",
    c3t: "Bots",
    c3d: "Non-blocking pop units triggered where they make sense in your bot flow, never in the middle of a task.",
    b1: "Revenue counted per validated impression, not per estimate.",
    b2: "Invalid traffic filtered before it reaches your balance.",
    b3: "Live dashboard: impressions, clicks, CTR and earnings per placement.",
    b4: "Withdraw from 50 USDT on TRON (TRC20) or TON.",
    cta: "Start monetizing",
  },
  adv: {
    tag: "For advertisers",
    title: "Put your product in front of an audience that is already engaged",
    sub: "Promote a platform, a company, an app, a token or a service. Your creative runs inside Telegram, where your audience already spends its day.",
    b1: "Launch from a $50 balance, funded in crypto or by card.",
    b2: "CPM buying from $1.70, with conversion tracking on every wrapped link.",
    b3: "Language targeting today, country targeting as inventory grows.",
    b4: "Up to 5 creatives per campaign, rotated until a winner emerges.",
    cta: "Launch a campaign",
  },
  money: {
    title: "How money moves",
    sub: "Two rails, no surprises: advertisers fund a balance, publishers withdraw a balance.",
    depT: "Advertiser deposits",
    depCrypto: "Crypto",
    depCryptoD: "USD₮ on TRON (TRC20), TON and BNB Smart Chain. Credited after network confirmation, network fee deducted from the amount sent.",
    depFiat: "Fiat",
    depFiatD: "Card and bank transfer for advertisers who invoice in EUR or USD. Same balance, same campaign engine.",
    wdT: "Publisher withdrawals",
    wdMin: "Minimum 50 USDT",
    wdMinD: "Request a payout as soon as your available balance reaches 50 USDT. Reviewed and released by our operations team.",
    wdNet: "TRX & TON networks",
    wdNetD: "Choose TRON (TRC20) or TON, add a memo or comment when your exchange requires one, and follow each request from pending to paid.",
    cpmT: "Minimum CPM",
    cpmD: "Advertisers never bid below this floor, which protects publisher revenue per thousand impressions.",
    floor: "$1.70",
  },
  test: {
    title: "Trusted by advertisers and publishers",
    sub: "Seven of the people building on AdsKinz today.",
    items: [
      { r: "Growth lead, crypto exchange", q: "We moved half of our acquisition budget to AdsKinz. Cost per registration dropped by a third compared to what we were paying for banner traffic." },
      { r: "Marketing manager, fintech app", q: "The native post format works because it does not look like an ad. Our click-through rate is roughly three times what we see anywhere else." },
      { r: "Owner, 180k subscriber channel", q: "One channel connected in ten minutes, and a first payout the same month. The dashboard shows exactly which post earned what." },
      { r: "Founder, mobile game studio", q: "Interstitials between two levels were the cleanest fit for us. The SDK took an afternoon and revenue has been steady since." },
      { r: "CEO, payments startup", q: "We needed reach in emerging markets. Language targeting got us in front of the right audience without wasting impressions." },
      { r: "Publisher, media network", q: "Payouts land on TON in under a day and the 50 USDT floor means I am not waiting months to be paid." },
      { r: "Mini App developer", q: "Anti-fraud filtering is real here. My numbers match what my own analytics report, which was never the case before." },
    ],
  },
  support: {
    title: "Talk to a human",
    sub: "Account, billing, moderation or SDK integration — we answer.",
    mailT: "Email support",
    mailD: "Written questions, invoices and account reviews.",
    botT: "Telegram support",
    botD: "The fastest way to reach us, directly inside Telegram.",
    hours: "Answers within one business day, every day of the week.",
  },
  cta: {
    title: "Two minutes to your first impression",
    sub: "Fund a balance and launch, or connect a placement and start earning.",
    btn: "Launch a campaign",
    btn2: "Monetize my traffic",
  },
  foot: {
    blurb: "Native advertising for Telegram channels, bots and Mini Apps. Paid in USDT.",
    powered: "Powered by SARA DEV",
    created: "Created by Kingcey",
    rights: "© 2026 AdsKinz. All rights reserved.",
    product: "Product",
    company: "Company",
    support: "Support",
  },
};

const fr: X = {
  hero: {
    badge: "La publicité native pensée pour Telegram",
    t1: "Monétisez votre canal et votre Mini App.",
    accent: "Développez votre business",
    t2: "avec des pubs qui restent natives.",
    sub: "AdsKinz relie les éditeurs Telegram aux annonceurs. Les éditeurs gagnent en USDT sur chaque impression réelle. Les annonceurs touchent des millions d'utilisateurs dans les canaux et les Mini Apps, dès 1,70 $ de CPM.",
    ctaAdv: "Annoncer sur AdsKinz",
    ctaPub: "Monétiser mon trafic",
    note: "Sans frais d'installation · Retrait minimum 50 USDT · TRC20 & TON",
  },
  kpi: { imp: "Impressions par mois", chan: "Canaux connectés", apps: "Mini Apps", paid: "Versé aux éditeurs", cpm: "CPM minimum" },
  monet: {
    tag: "Pour les éditeurs",
    title: "Transformez votre audience Telegram en revenu mensuel",
    sub: "Connectez un canal, un bot ou une Mini App une seule fois. Les pubs sont associées à votre langue, diffusées nativement et payées en USDT.",
    c1t: "Canaux",
    c1d: "Posts sponsorisés natifs publiés dans votre fil. Vous gardez le contrôle de la fréquence — jusqu'à 3 posts par jour.",
    c2t: "Mini Apps",
    c2d: "Interstitiels plein écran entre deux actions, intégrés avec le SDK Kinz-ID en quelques lignes de code.",
    c3t: "Bots",
    c3d: "Unités pop non bloquantes déclenchées au bon moment du parcours, jamais au milieu d'une action.",
    b1: "Revenu compté par impression validée, pas par estimation.",
    b2: "Trafic invalide filtré avant d'atteindre votre solde.",
    b3: "Tableau de bord en direct : impressions, clics, CTR et gains par emplacement.",
    b4: "Retrait dès 50 USDT sur TRON (TRC20) ou TON.",
    cta: "Commencer à monétiser",
  },
  adv: {
    tag: "Pour les annonceurs",
    title: "Placez votre produit devant une audience déjà engagée",
    sub: "Faites la promotion d'une plateforme, d'une entreprise, d'une app, d'un token ou d'un service. Votre créatif tourne dans Telegram, là où votre audience passe déjà ses journées.",
    b1: "Lancez dès 50 $ de solde, rechargé en crypto ou par carte.",
    b2: "Achat au CPM dès 1,70 $, avec suivi de conversion sur chaque lien encapsulé.",
    b3: "Ciblage par langue aujourd'hui, par pays à mesure que l'inventaire grandit.",
    b4: "Jusqu'à 5 créatifs par campagne, en rotation jusqu'au gagnant.",
    cta: "Lancer une campagne",
  },
  money: {
    title: "Comment circule l'argent",
    sub: "Deux flux, sans surprise : l'annonceur recharge un solde, l'éditeur retire un solde.",
    depT: "Dépôts annonceurs",
    depCrypto: "Crypto",
    depCryptoD: "USD₮ sur TRON (TRC20), TON et BNB Smart Chain. Crédité après confirmation réseau, frais réseau déduits du montant envoyé.",
    depFiat: "Fiat",
    depFiatD: "Carte bancaire et virement pour les annonceurs qui facturent en EUR ou en USD. Même solde, même moteur de campagne.",
    wdT: "Retraits éditeurs",
    wdMin: "Minimum 50 USDT",
    wdMinD: "Demandez un paiement dès que votre solde disponible atteint 50 USDT. Vérifié puis libéré par notre équipe.",
    wdNet: "Réseaux TRX & TON",
    wdNetD: "Choisissez TRON (TRC20) ou TON, ajoutez un memo/commentaire si votre exchange l'exige, et suivez chaque demande de « en attente » à « payé ».",
    cpmT: "CPM minimum",
    cpmD: "Aucun annonceur ne descend sous ce plancher, ce qui protège le revenu des éditeurs pour mille impressions.",
    floor: "1,70 $",
  },
  test: {
    title: "La confiance des annonceurs et des éditeurs",
    sub: "Sept des personnes qui construisent sur AdsKinz aujourd'hui.",
    items: [
      { r: "Responsable growth, exchange crypto", q: "Nous avons basculé la moitié de notre budget d'acquisition sur AdsKinz. Le coût par inscription a baissé d'un tiers face au trafic bannière." },
      { r: "Responsable marketing, app fintech", q: "Le post natif fonctionne parce qu'il ne ressemble pas à une pub. Notre taux de clic est environ trois fois supérieur à ailleurs." },
      { r: "Propriétaire, canal de 180k abonnés", q: "Un canal connecté en dix minutes, un premier paiement le mois même. Le dashboard montre exactement quel post a rapporté quoi." },
      { r: "Fondateur, studio de jeux mobiles", q: "Les interstitiels entre deux niveaux étaient le format le plus propre pour nous. Le SDK a pris une après-midi." },
      { r: "CEO, startup de paiement", q: "Il nous fallait de la portée sur les marchés émergents. Le ciblage par langue nous a mis devant la bonne audience sans gaspiller d'impressions." },
      { r: "Éditeur, réseau média", q: "Les paiements arrivent sur TON en moins d'un jour et le seuil de 50 USDT évite d'attendre des mois." },
      { r: "Développeur de Mini App", q: "Le filtrage anti-fraude est réel. Mes chiffres correspondent à mes propres analytics, ce qui n'était jamais le cas avant." },
    ],
  },
  support: {
    title: "Parlez à un humain",
    sub: "Compte, facturation, modération ou intégration SDK — nous répondons.",
    mailT: "Support e-mail",
    mailD: "Questions écrites, factures et vérifications de compte.",
    botT: "Support Telegram",
    botD: "Le moyen le plus rapide de nous joindre, directement dans Telegram.",
    hours: "Réponse sous un jour ouvré, tous les jours de la semaine.",
  },
  cta: {
    title: "Deux minutes jusqu'à votre première impression",
    sub: "Rechargez un solde et lancez, ou connectez un emplacement et commencez à gagner.",
    btn: "Lancer une campagne",
    btn2: "Monétiser mon trafic",
  },
  foot: {
    blurb: "Publicité native pour les canaux, bots et Mini Apps Telegram. Payée en USDT.",
    powered: "Propulsé par SARA DEV",
    created: "Créé par Kingcey",
    rights: "© 2026 AdsKinz. Tous droits réservés.",
    product: "Produit",
    company: "Entreprise",
    support: "Support",
  },
};

const ru: X = {
  hero: {
    badge: "Нативная реклама, созданная для Telegram",
    t1: "Монетизируйте канал и Mini App.",
    accent: "Развивайте бизнес",
    t2: "с рекламой, которая выглядит нативно.",
    sub: "AdsKinz соединяет паблишеров Telegram с рекламодателями. Паблишеры получают USDT за каждый реальный показ. Рекламодатели выходят к миллионам пользователей в каналах и Mini Apps от CPM $1.70.",
    ctaAdv: "Рекламироваться",
    ctaPub: "Монетизировать трафик",
    note: "Без платы за подключение · Минимальная выплата 50 USDT · TRC20 и TON",
  },
  kpi: { imp: "Показов в месяц", chan: "Подключённых каналов", apps: "Mini Apps", paid: "Выплачено паблишерам", cpm: "Минимальный CPM" },
  monet: {
    tag: "Для паблишеров",
    title: "Превратите аудиторию Telegram в ежемесячный доход",
    sub: "Подключите канал, бота или Mini App один раз. Реклама подбирается по языку, показывается нативно и оплачивается в USDT.",
    c1t: "Каналы",
    c1d: "Нативные рекламные посты в вашей ленте. Частоту контролируете вы — до 3 постов в день.",
    c2t: "Mini Apps",
    c2d: "Полноэкранные интерстишлы между двумя действиями, интеграция через SDK Kinz-ID за несколько строк кода.",
    c3t: "Боты",
    c3d: "Неблокирующие pop-блоки в подходящий момент сценария, никогда посреди задачи.",
    b1: "Доход считается по подтверждённым показам, а не по оценке.",
    b2: "Невалидный трафик отсеивается до попадания на баланс.",
    b3: "Живой дашборд: показы, клики, CTR и доход по каждому размещению.",
    b4: "Вывод от 50 USDT в сети TRON (TRC20) или TON.",
    cta: "Начать монетизацию",
  },
  adv: {
    tag: "Для рекламодателей",
    title: "Покажите продукт уже вовлечённой аудитории",
    sub: "Продвигайте платформу, компанию, приложение, токен или сервис. Ваш креатив работает внутри Telegram.",
    b1: "Старт от баланса $50, пополнение криптой или картой.",
    b2: "Закупка по CPM от $1.70 с отслеживанием конверсий по каждой ссылке.",
    b3: "Сегодня таргетинг по языку, позже по странам по мере роста инвентаря.",
    b4: "До 5 креативов на кампанию с ротацией до победителя.",
    cta: "Запустить кампанию",
  },
  money: {
    title: "Как движутся деньги",
    sub: "Два потока без сюрпризов: рекламодатель пополняет баланс, паблишер выводит баланс.",
    depT: "Пополнения рекламодателей",
    depCrypto: "Крипто",
    depCryptoD: "USD₮ в сетях TRON (TRC20), TON и BNB Smart Chain. Зачисление после подтверждения сети, комиссия сети вычитается из суммы.",
    depFiat: "Фиат",
    depFiatD: "Карта и банковский перевод для тех, кто работает в EUR или USD. Тот же баланс, тот же движок кампаний.",
    wdT: "Выплаты паблишерам",
    wdMin: "Минимум 50 USDT",
    wdMinD: "Запросите выплату, как только доступный баланс достигнет 50 USDT. Проверяется и выпускается нашей командой.",
    wdNet: "Сети TRX и TON",
    wdNetD: "Выберите TRON (TRC20) или TON, добавьте memo/комментарий, если этого требует биржа, и следите за статусом от «в ожидании» до «выплачено».",
    cpmT: "Минимальный CPM",
    cpmD: "Ставки не опускаются ниже этого порога — это защищает доход паблишера за тысячу показов.",
    floor: "$1.70",
  },
  test: {
    title: "Нам доверяют рекламодатели и паблишеры",
    sub: "Семь человек, которые уже строят на AdsKinz.",
    items: [
      { r: "Growth-лид, криптобиржа", q: "Мы перевели половину бюджета на AdsKinz. Стоимость регистрации упала на треть по сравнению с баннерным трафиком." },
      { r: "Маркетинг-менеджер, финтех", q: "Нативный пост работает, потому что не выглядит рекламой. CTR примерно втрое выше, чем где-либо ещё." },
      { r: "Владелец канала на 180k", q: "Канал подключил за десять минут, первая выплата в тот же месяц. Видно, какой пост сколько принёс." },
      { r: "Основатель, мобильные игры", q: "Интерстишлы между уровнями подошли идеально. SDK занял полдня, доход стабилен." },
      { r: "CEO, платёжный стартап", q: "Нам был нужен охват на развивающихся рынках. Таргетинг по языку дал нужную аудиторию без слива показов." },
      { r: "Паблишер, медиасеть", q: "Выплаты приходят на TON меньше чем за сутки, а порог в 50 USDT избавляет от долгого ожидания." },
      { r: "Разработчик Mini App", q: "Антифрод здесь настоящий. Мои цифры совпадают с собственной аналитикой." },
    ],
  },
  support: {
    title: "Поговорите с человеком",
    sub: "Аккаунт, оплата, модерация или интеграция SDK — мы отвечаем.",
    mailT: "Поддержка по e-mail",
    mailD: "Письменные вопросы, счета и проверки аккаунта.",
    botT: "Поддержка в Telegram",
    botD: "Самый быстрый способ связаться, прямо в Telegram.",
    hours: "Ответ в течение одного рабочего дня, каждый день недели.",
  },
  cta: {
    title: "Две минуты до первого показа",
    sub: "Пополните баланс и запускайте, или подключите размещение и зарабатывайте.",
    btn: "Запустить кампанию",
    btn2: "Монетизировать трафик",
  },
  foot: {
    blurb: "Нативная реклама для каналов, ботов и Mini Apps Telegram. Оплата в USDT.",
    powered: "При поддержке SARA DEV",
    created: "Создано Kingcey",
    rights: "© 2026 AdsKinz. Все права защищены.",
    product: "Продукт",
    company: "Компания",
    support: "Поддержка",
  },
};

const zh: X = {
  hero: {
    badge: "为 Telegram 打造的原生广告",
    t1: "让您的频道与小程序产生收入。",
    accent: "拓展您的业务",
    t2: "使用真正原生的广告。",
    sub: "AdsKinz 连接 Telegram 发布者与广告主。发布者按真实展示以 USDT 结算；广告主以最低 $1.70 CPM 触达频道与小程序中的数百万用户。",
    ctaAdv: "开始投放广告",
    ctaPub: "开始流量变现",
    note: "无接入费 · 最低提现 50 USDT · 支持 TRC20 与 TON",
  },
  kpi: { imp: "月展示量", chan: "已接入频道", apps: "小程序", paid: "已支付给发布者", cpm: "最低 CPM" },
  monet: {
    tag: "面向发布者",
    title: "把您的 Telegram 受众变成每月收入",
    sub: "一次接入频道、机器人或小程序。广告按语言匹配、原生投放，并以 USDT 结算。",
    c1t: "频道",
    c1d: "在信息流中发布的原生赞助帖，频率由您掌控——每天最多 3 条。",
    c2t: "小程序",
    c2d: "两次操作之间的全屏插屏，通过 Kinz-ID SDK 几行代码即可接入。",
    c3t: "机器人",
    c3d: "在合适节点触发的非阻断浮层，绝不打断用户正在进行的任务。",
    b1: "按验证后的展示计费，而非估算。",
    b2: "无效流量在进入余额前被过滤。",
    b3: "实时看板：每个展位的展示、点击、CTR 与收益。",
    b4: "满 50 USDT 即可通过 TRON (TRC20) 或 TON 提现。",
    cta: "开始变现",
  },
  adv: {
    tag: "面向广告主",
    title: "把产品呈现在已被激活的受众面前",
    sub: "推广平台、公司、应用、代币或服务。您的素材在 Telegram 内部投放。",
    b1: "$50 余额即可开跑，支持加密货币或银行卡充值。",
    b2: "CPM 起投 $1.70，每条包装链接均可跟踪转化。",
    b3: "当前按语言定向，随库存增长支持国家定向。",
    b4: "每个活动最多 5 个素材，轮播直至胜出。",
    cta: "创建广告活动",
  },
  money: {
    title: "资金如何流动",
    sub: "两条通道，毫无意外：广告主充值余额，发布者提取余额。",
    depT: "广告主充值",
    depCrypto: "加密货币",
    depCryptoD: "支持 TRON (TRC20)、TON 与 BNB Smart Chain 的 USD₮。网络确认后到账，网络手续费从转账金额中扣除。",
    depFiat: "法币",
    depFiatD: "为以 EUR 或 USD 结算的广告主提供银行卡与电汇。同一余额，同一投放引擎。",
    wdT: "发布者提现",
    wdMin: "最低 50 USDT",
    wdMinD: "可用余额达到 50 USDT 即可申请提现，由运营团队审核放款。",
    wdNet: "TRX 与 TON 网络",
    wdNetD: "选择 TRON (TRC20) 或 TON，交易所需要时填写 memo/备注，并跟踪每笔申请从待处理到已支付。",
    cpmT: "最低 CPM",
    cpmD: "出价不会低于该下限，从而保障发布者的千次展示收入。",
    floor: "$1.70",
  },
  test: {
    title: "广告主与发布者的共同选择",
    sub: "正在使用 AdsKinz 的七位伙伴。",
    items: [
      { r: "增长负责人，加密交易所", q: "我们把一半获客预算迁到 AdsKinz，单次注册成本比横幅流量低了三分之一。" },
      { r: "市场经理，金融科技应用", q: "原生帖有效，是因为它看起来不像广告。我们的点击率大约是其他渠道的三倍。" },
      { r: "18 万订阅频道主", q: "十分钟接入频道，当月就收到第一笔款项，看板清楚显示每条帖子的收益。" },
      { r: "创始人，手游工作室", q: "关卡之间的插屏最适合我们。SDK 半天接完，收入一直稳定。" },
      { r: "CEO，支付创业公司", q: "我们需要新兴市场的覆盖，语言定向让我们精准触达而不浪费展示。" },
      { r: "发布者，媒体网络", q: "TON 提现不到一天到账，50 USDT 的门槛让我不必等上几个月。" },
      { r: "小程序开发者", q: "这里的反作弊是真的，我的数据与自有分析一致，以前从未如此。" },
    ],
  },
  support: {
    title: "与真人沟通",
    sub: "账户、账单、审核或 SDK 接入，我们都会回复。",
    mailT: "邮件支持",
    mailD: "书面咨询、发票与账户审核。",
    botT: "Telegram 支持",
    botD: "最快的联系方式，就在 Telegram 内。",
    hours: "一个工作日内回复，全周无休。",
  },
  cta: {
    title: "两分钟拿到第一次展示",
    sub: "充值并投放，或接入展位开始赚取收入。",
    btn: "创建广告活动",
    btn2: "开始流量变现",
  },
  foot: {
    blurb: "面向 Telegram 频道、机器人与小程序的原生广告，USDT 结算。",
    powered: "由 SARA DEV 提供技术支持",
    created: "由 Kingcey 创建",
    rights: "© 2026 AdsKinz. 保留所有权利。",
    product: "产品",
    company: "公司",
    support: "支持",
  },
};

export const testimonialNames = names;

export const landing2 = {
  en: { x: en },
  fr: { x: fr },
  ru: { x: ru },
  zh: { x: zh },
};
