/**
 * Publisher dashboard + channel link validation dictionary (namespace `pb`).
 * English is the source of truth; fr/ru/zh mirror it key for key.
 */

type P = {
  kpi: { ecpm: string; fill: string; ctr: string; ads: string; active: string; hint: string };
  slots: { title: string; sub: string; none: string; colPlacement: string; colWhen: string; colCampaign: string };
  log: {
    title: string;
    sub: string;
    colWhen: string;
    colCampaign: string;
    colPlacement: string;
    colImpr: string;
    colClicks: string;
    colCtr: string;
    colEarn: string;
    none: string;
  };
  geo: { title: string; sub: string; colCountry: string; colShare: string; colImpr: string; colEarn: string };
  health: { title: string; sub: string; ok: string; warn: string; bot: string; frequency: string; quality: string };
  link: {
    label: string;
    privateT: string;
    privateD: string;
    publicT: string;
    publicD: string;
    invalidT: string;
    invalidD: string;
    blocked: string;
  };
};

const en: P = {
  kpi: {
    ecpm: "Average eCPM",
    fill: "Fill rate",
    ctr: "Average CTR",
    ads: "Ads delivered (30d)",
    active: "Active placements",
    hint: "Across the placements matching your filters.",
  },
  slots: {
    title: "Upcoming ad slots",
    sub: "The next native posts scheduled in your channels.",
    none: "No slot scheduled right now.",
    colPlacement: "Placement",
    colWhen: "Scheduled for",
    colCampaign: "Campaign",
  },
  log: {
    title: "Ad delivery log",
    sub: "Every ad served in your channels and Mini Apps, with what it earned you.",
    colWhen: "Date",
    colCampaign: "Campaign",
    colPlacement: "Placement",
    colImpr: "Impressions",
    colClicks: "Clicks",
    colCtr: "CTR",
    colEarn: "Earned",
    none: "No ad delivered in this window yet.",
  },
  geo: {
    title: "Where your audience is",
    sub: "Share of impressions and earnings by country over the last 30 days.",
    colCountry: "Country",
    colShare: "Share",
    colImpr: "Impressions",
    colEarn: "Earnings",
  },
  health: {
    title: "Placement health",
    sub: "What could hold your earnings back right now.",
    ok: "All good",
    warn: "Needs attention",
    bot: "Bot admin rights",
    frequency: "Daily ad frequency",
    quality: "Traffic quality score",
  },
  link: {
    label: "Public link",
    privateT: "Private invite link detected",
    privateD:
      "Links starting with https://t.me/+ or /joinchat/ are private invites. Private channels are not accepted — publish your channel and paste its public t.me link.",
    publicT: "Public link detected",
    publicD: "This channel can be reviewed. Add our bot as administrator before submitting.",
    invalidT: "This is not a Telegram link",
    invalidD: "A channel link looks like https://t.me/yourchannel.",
    blocked: "Fix the channel link before submitting.",
  },
};

const fr: P = {
  kpi: {
    ecpm: "eCPM moyen",
    fill: "Taux de remplissage",
    ctr: "CTR moyen",
    ads: "Pubs diffusées (30 j)",
    active: "Emplacements actifs",
    hint: "Sur les emplacements correspondant à vos filtres.",
  },
  slots: {
    title: "Prochains créneaux publicitaires",
    sub: "Les prochaines publications natives programmées dans vos canaux.",
    none: "Aucun créneau programmé pour le moment.",
    colPlacement: "Emplacement",
    colWhen: "Programmé pour",
    colCampaign: "Campagne",
  },
  log: {
    title: "Journal de diffusion",
    sub: "Chaque pub diffusée dans vos canaux et Mini Apps, avec ce qu'elle vous a rapporté.",
    colWhen: "Date",
    colCampaign: "Campagne",
    colPlacement: "Emplacement",
    colImpr: "Impressions",
    colClicks: "Clics",
    colCtr: "CTR",
    colEarn: "Gains",
    none: "Aucune pub diffusée sur cette période.",
  },
  geo: {
    title: "Où se trouve votre audience",
    sub: "Répartition des impressions et des gains par pays sur 30 jours.",
    colCountry: "Pays",
    colShare: "Part",
    colImpr: "Impressions",
    colEarn: "Gains",
  },
  health: {
    title: "Santé des emplacements",
    sub: "Ce qui peut freiner vos gains en ce moment.",
    ok: "Tout est bon",
    warn: "À vérifier",
    bot: "Droits d'administrateur du bot",
    frequency: "Fréquence de pubs par jour",
    quality: "Score de qualité du trafic",
  },
  link: {
    label: "Lien public",
    privateT: "Lien d'invitation privé détecté",
    privateD:
      "Les liens commençant par https://t.me/+ ou /joinchat/ sont des invitations privées. Les canaux privés ne sont pas acceptés — rendez votre canal public et collez son lien t.me public.",
    publicT: "Lien public détecté",
    publicD: "Ce canal peut être vérifié. Ajoutez notre bot comme administrateur avant d'envoyer.",
    invalidT: "Ce n'est pas un lien Telegram",
    invalidD: "Un lien de canal ressemble à https://t.me/moncanal.",
    blocked: "Corrigez le lien du canal avant d'envoyer.",
  },
};

const ru: P = {
  kpi: {
    ecpm: "Средний eCPM",
    fill: "Заполняемость",
    ctr: "Средний CTR",
    ads: "Показано реклам (30 дн.)",
    active: "Активные площадки",
    hint: "По площадкам, подходящим под ваши фильтры.",
  },
  slots: {
    title: "Ближайшие слоты",
    sub: "Следующие нативные посты, запланированные в ваших каналах.",
    none: "Слотов пока нет.",
    colPlacement: "Площадка",
    colWhen: "Запланировано",
    colCampaign: "Кампания",
  },
  log: {
    title: "Журнал показов",
    sub: "Каждая реклама в ваших каналах и Mini Apps и её доход.",
    colWhen: "Дата",
    colCampaign: "Кампания",
    colPlacement: "Площадка",
    colImpr: "Показы",
    colClicks: "Клики",
    colCtr: "CTR",
    colEarn: "Доход",
    none: "За этот период показов не было.",
  },
  geo: {
    title: "География аудитории",
    sub: "Доля показов и дохода по странам за 30 дней.",
    colCountry: "Страна",
    colShare: "Доля",
    colImpr: "Показы",
    colEarn: "Доход",
  },
  health: {
    title: "Состояние площадок",
    sub: "Что сейчас может ограничивать ваш доход.",
    ok: "Всё в порядке",
    warn: "Требует внимания",
    bot: "Права администратора бота",
    frequency: "Частота реклам в день",
    quality: "Оценка качества трафика",
  },
  link: {
    label: "Публичная ссылка",
    privateT: "Обнаружена приватная ссылка-приглашение",
    privateD:
      "Ссылки, начинающиеся с https://t.me/+ или /joinchat/, — приватные приглашения. Приватные каналы не принимаются: сделайте канал публичным и вставьте его публичную ссылку t.me.",
    publicT: "Публичная ссылка распознана",
    publicD: "Канал можно отправить на проверку. Сначала добавьте нашего бота администратором.",
    invalidT: "Это не ссылка Telegram",
    invalidD: "Ссылка на канал выглядит так: https://t.me/yourchannel.",
    blocked: "Исправьте ссылку канала перед отправкой.",
  },
};

const zh: P = {
  kpi: {
    ecpm: "平均 eCPM",
    fill: "填充率",
    ctr: "平均点击率",
    ads: "已投放广告（30 天）",
    active: "活跃广告位",
    hint: "基于当前筛选条件下的广告位。",
  },
  slots: {
    title: "即将到来的广告时段",
    sub: "你的频道中下一批已排期的原生贴文。",
    none: "目前没有排期。",
    colPlacement: "广告位",
    colWhen: "排期时间",
    colCampaign: "广告活动",
  },
  log: {
    title: "投放记录",
    sub: "频道与小程序中的每一次广告投放及其收益。",
    colWhen: "日期",
    colCampaign: "广告活动",
    colPlacement: "广告位",
    colImpr: "展示",
    colClicks: "点击",
    colCtr: "点击率",
    colEarn: "收益",
    none: "该时间段暂无投放。",
  },
  geo: {
    title: "受众分布",
    sub: "近 30 天各国家的展示与收益占比。",
    colCountry: "国家",
    colShare: "占比",
    colImpr: "展示",
    colEarn: "收益",
  },
  health: {
    title: "广告位健康度",
    sub: "当前可能限制收益的因素。",
    ok: "一切正常",
    warn: "需要处理",
    bot: "机器人管理员权限",
    frequency: "每日广告条数",
    quality: "流量质量评分",
  },
  link: {
    label: "公开链接",
    privateT: "检测到私有邀请链接",
    privateD:
      "以 https://t.me/+ 或 /joinchat/ 开头的链接属于私有邀请。我们不接受私有频道——请将频道设为公开并粘贴其公开 t.me 链接。",
    publicT: "已识别公开链接",
    publicD: "该频道可以提交审核。提交前请将我们的机器人设为管理员。",
    invalidT: "这不是 Telegram 链接",
    invalidD: "频道链接形如 https://t.me/yourchannel。",
    blocked: "请先修正频道链接再提交。",
  },
};

export const pubDict = {
  en: { pb: en },
  fr: { pb: fr },
  ru: { pb: ru },
  zh: { pb: zh },
};

/** Classifies a pasted Telegram link while the publisher types. */
export type LinkKind = "empty" | "private" | "public" | "invalid";

export function classifyTelegramLink(raw: string): LinkKind {
  const v = raw.trim();
  if (!v) return "empty";
  if (/^(https?:\/\/)?(t\.me|telegram\.me)\/(\+|joinchat\/)/i.test(v)) return "private";
  if (/^https:\/\/t\.me\/[A-Za-z0-9_]{4,}$/i.test(v)) return "public";
  return "invalid";
}
