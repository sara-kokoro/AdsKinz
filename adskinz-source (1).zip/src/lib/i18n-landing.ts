/**
 * Additive landing-page dictionary (spec sections 2.7 – 2.12): hero pillar
 * badges, business use cases, "why AdsKinz", the format specification table
 * and the extended technical FAQ. Keys live under the `l` namespace.
 */

type Land = {
  pillars: { native: string; targeting: string; fraud: string };
  use: { title: string; sub: string } & Record<`t${1 | 2 | 3 | 4 | 5 | 6}` | `d${1 | 2 | 3 | 4 | 5 | 6}`, string>;
  why: { title: string; sub: string } & Record<`t${1 | 2 | 3 | 4 | 5 | 6}` | `d${1 | 2 | 3 | 4 | 5 | 6}`, string>;
  spec: {
    title: string;
    sub: string;
    format: string;
    type: string;
    custom: string;
    targeting: string;
    strategy: string;
    nativePost: string;
    interstitial: string;
    pop: string;
    typeNative: string;
    typeInter: string;
    typePop: string;
    customAll: string;
    customApp: string;
    targetingVal: string;
    strategyVal: string;
  };
  faq2: Record<`q${1 | 2 | 3 | 4}` | `a${1 | 2 | 3 | 4}`, string>;
};

const en: Land = {
  pillars: { native: "Native formats", targeting: "Precise targeting", fraud: "Anti-fraud" },
  use: {
    title: "Built around your objective",
    sub: "Pick the outcome you are buying. The format follows from it.",
    t1: "User acquisition",
    d1: "Drive people to a site, an app or an external Mini App, with conversion tracking on the wrapped link.",
    t2: "Channel growth",
    d2: "Gain real subscribers from channels that match your language. No artificial inflation, no bought lists.",
    t3: "Bot growth",
    d3: "Bring in users who actually start and interact with your bot, not one-time openers.",
    t4: "Mini App growth",
    d4: "Find your first users, or expand an audience you already have, across the Mini App inventory.",
    t5: "Performance campaigns",
    d5: "CPM buying with conversion tracking so you can read cost per outcome, not just cost per view.",
    t6: "Crypto, gaming, fintech",
    d6: "Verticals where Telegram and TON audiences already live, and where AdsKinz inventory is strongest.",
  },
  why: {
    title: "Why AdsKinz",
    sub: "Concrete guarantees, not a feature list.",
    t1: "Anti-fraud protection",
    d1: "Invalid impressions are filtered out before billing. You pay for real views only.",
    t2: "Fast launch",
    d2: "From sign-up to live delivery in under 5 minutes once your balance is funded.",
    t3: "Flexible formats",
    d3: "One creative can be reused across several inventory formats without rebuilding it.",
    t4: "Precise targeting",
    d4: "Target by language today, with country targeting coming when the data supports it.",
    t5: "100% native inventory",
    d5: "Every placement stays inside Telegram. Your ad never leaves the ecosystem.",
    t6: "Transparent pricing",
    d6: "The CPM you see is the CPM you pay. No hidden fees, no undisclosed margin.",
  },
  spec: {
    title: "Format specifications",
    sub: "For advertisers who want the technical detail before committing budget.",
    format: "Format",
    type: "Type",
    custom: "Customization",
    targeting: "Targeting",
    strategy: "Strategy",
    nativePost: "Native post",
    interstitial: "Interstitial",
    pop: "Pop interstitial",
    typeNative: "Image + text post published in the channel feed",
    typeInter: "Full-screen unit between two Mini App actions",
    typePop: "Non-blocking overlay triggered by the publisher",
    customAll: "Link, image, title, text, button label",
    customApp: "Link, image, title, text, button label",
    targetingVal: "Language (country later)",
    strategyVal: "CPM only",
  },
  faq2: {
    q1: "Which timezone is used for daily budgets and statistics?",
    a1: "Everything runs on UTC+0. Daily budgets and daily statistics reset at 00:00 UTC.",
    q2: "How many creatives can I test inside one campaign?",
    a2: "Up to 5 creatives per campaign. They rotate evenly until one shows a clear delivery advantage.",
    q3: "How is fraudulent traffic detected and filtered?",
    a3: "Impressions and clicks are scored for pattern anomalies. Flagged placements are quarantined for human review and the impressions are not billed.",
    q4: "Can a conversion event be reported after a user finished watching the ad?",
    a4: "Yes. Mini App interstitial formats can report a completion event back through the Kinz-ID SDK, which is what conversion tracking reads.",
  },
};

const fr: Land = {
  pillars: { native: "Formats natifs", targeting: "Ciblage précis", fraud: "Anti-fraude" },
  use: {
    title: "Construit autour de votre objectif",
    sub: "Choisissez le résultat que vous achetez. Le format en découle.",
    t1: "Acquisition d'utilisateurs",
    d1: "Dirigez vers un site, une app ou une Mini App externe, avec suivi de conversion sur le lien encapsulé.",
    t2: "Croissance de canal",
    d2: "Gagnez de vrais abonnés depuis des canaux de votre langue. Aucune inflation artificielle.",
    t3: "Croissance de bot",
    d3: "Des utilisateurs qui démarrent et interagissent réellement avec votre bot.",
    t4: "Croissance de Mini App",
    d4: "Trouvez vos premiers utilisateurs, ou élargissez une audience existante.",
    t5: "Campagnes performance",
    d5: "Achat au CPM avec suivi de conversion : lisez le coût par résultat, pas seulement par vue.",
    t6: "Crypto, gaming, fintech",
    d6: "Les verticales où les audiences Telegram et TON sont déjà présentes.",
  },
  why: {
    title: "Pourquoi AdsKinz",
    sub: "Des garanties concrètes, pas une liste de fonctionnalités.",
    t1: "Protection anti-fraude",
    d1: "Les impressions invalides sont filtrées avant facturation. Vous ne payez que des vues réelles.",
    t2: "Lancement rapide",
    d2: "De l'inscription à la diffusion en moins de 5 minutes une fois le solde rechargé.",
    t3: "Formats flexibles",
    d3: "Un même créatif se réutilise sur plusieurs formats d'inventaire sans le refaire.",
    t4: "Ciblage précis",
    d4: "Ciblage par langue aujourd'hui, pays plus tard quand la donnée le permettra.",
    t5: "Inventaire 100% natif",
    d5: "Chaque emplacement reste dans Telegram. Votre pub ne sort jamais de l'écosystème.",
    t6: "Tarification transparente",
    d6: "Le CPM affiché est le CPM payé. Pas de frais cachés, pas de marge dissimulée.",
  },
  spec: {
    title: "Spécifications par format",
    sub: "Pour les annonceurs qui veulent le détail technique avant d'engager un budget.",
    format: "Format",
    type: "Type",
    custom: "Personnalisation",
    targeting: "Ciblage",
    strategy: "Stratégie",
    nativePost: "Native post",
    interstitial: "Interstitiel",
    pop: "Pop interstitiel",
    typeNative: "Post image + texte publié dans le fil du canal",
    typeInter: "Unité plein écran entre deux actions de la Mini App",
    typePop: "Superposition non bloquante déclenchée par le publisher",
    customAll: "Lien, image, titre, texte, libellé du bouton",
    customApp: "Lien, image, titre, texte, libellé du bouton",
    targetingVal: "Langue (pays plus tard)",
    strategyVal: "CPM uniquement",
  },
  faq2: {
    q1: "Quel fuseau horaire est utilisé pour les budgets et statistiques journalières ?",
    a1: "Tout fonctionne en UTC+0. Les budgets et statistiques journalières se réinitialisent à 00:00 UTC.",
    q2: "Combien de créatifs puis-je tester dans une même campagne ?",
    a2: "Jusqu'à 5 créatifs par campagne. Ils tournent équitablement jusqu'à ce que l'un se détache.",
    q3: "Comment le trafic frauduleux est-il détecté et filtré ?",
    a3: "Impressions et clics sont scorés pour repérer les anomalies. Les emplacements flaggés passent en quarantaine et les impressions ne sont pas facturées.",
    q4: "Un événement de conversion peut-il remonter après que l'utilisateur a vu la pub jusqu'au bout ?",
    a4: "Oui. Les formats interstitiels Mini App remontent un événement de fin via le SDK Kinz-ID, que le suivi de conversion utilise.",
  },
};

const ru: Land = {
  pillars: { native: "Нативные форматы", targeting: "Точный таргетинг", fraud: "Антифрод" },
  use: {
    title: "Построено вокруг вашей цели",
    sub: "Выберите результат, который покупаете. Формат следует из него.",
    t1: "Привлечение пользователей",
    d1: "Ведите на сайт, приложение или внешнее Mini App с отслеживанием конверсий по обёрнутой ссылке.",
    t2: "Рост канала",
    d2: "Реальные подписчики из каналов на вашем языке. Без искусственной накрутки.",
    t3: "Рост бота",
    d3: "Пользователи, которые действительно запускают бота и взаимодействуют с ним.",
    t4: "Рост Mini App",
    d4: "Найдите первых пользователей или расширьте уже существующую аудиторию.",
    t5: "Performance-кампании",
    d5: "Закупка по CPM с отслеживанием конверсий: стоимость результата, а не только показа.",
    t6: "Крипто, гейминг, финтех",
    d6: "Вертикали, где аудитории Telegram и TON уже живут.",
  },
  why: {
    title: "Почему AdsKinz",
    sub: "Конкретные гарантии, а не список функций.",
    t1: "Защита от фрода",
    d1: "Невалидные показы отсеиваются до биллинга. Вы платите только за реальные просмотры.",
    t2: "Быстрый запуск",
    d2: "От регистрации до показов менее чем за 5 минут после пополнения баланса.",
    t3: "Гибкие форматы",
    d3: "Один креатив переиспользуется в нескольких форматах инвентаря.",
    t4: "Точный таргетинг",
    d4: "Сегодня — по языку, позже добавим страны, когда данных будет достаточно.",
    t5: "100% нативный инвентарь",
    d5: "Все размещения остаются внутри Telegram.",
    t6: "Прозрачные цены",
    d6: "Показанный CPM — это оплаченный CPM. Без скрытых комиссий.",
  },
  spec: {
    title: "Спецификации форматов",
    sub: "Для рекламодателей, которым нужны технические детали до запуска бюджета.",
    format: "Формат",
    type: "Тип",
    custom: "Настройка",
    targeting: "Таргетинг",
    strategy: "Стратегия",
    nativePost: "Нативный пост",
    interstitial: "Интерстишл",
    pop: "Pop-интерстишл",
    typeNative: "Пост с изображением и текстом в ленте канала",
    typeInter: "Полноэкранный блок между двумя действиями в Mini App",
    typePop: "Неблокирующее наложение по триггеру паблишера",
    customAll: "Ссылка, изображение, заголовок, текст, надпись кнопки",
    customApp: "Ссылка, изображение, заголовок, текст, надпись кнопки",
    targetingVal: "Язык (страна позже)",
    strategyVal: "Только CPM",
  },
  faq2: {
    q1: "Какой часовой пояс используется для дневных бюджетов и статистики?",
    a1: "Всё работает по UTC+0. Дневные бюджеты и статистика обнуляются в 00:00 UTC.",
    q2: "Сколько креативов можно тестировать в одной кампании?",
    a2: "До 5 креативов на кампанию. Они ротируются равномерно, пока один не покажет явное преимущество.",
    q3: "Как выявляется и фильтруется фродовый трафик?",
    a3: "Показы и клики оцениваются на аномалии. Помеченные размещения уходят на ручную проверку, показы не тарифицируются.",
    q4: "Можно ли передать событие конверсии после полного просмотра рекламы?",
    a4: "Да. Интерстишл-форматы Mini App передают событие завершения через SDK Kinz-ID.",
  },
};

const zh: Land = {
  pillars: { native: "原生格式", targeting: "精准定向", fraud: "反作弊" },
  use: {
    title: "围绕您的业务目标构建",
    sub: "先选定要购买的结果，格式随之而来。",
    t1: "用户获取",
    d1: "引流至网站、应用或外部小程序，并在包装链接上跟踪转化。",
    t2: "频道增长",
    d2: "从同语言频道获得真实订阅者，杜绝虚假膨胀。",
    t3: "机器人增长",
    d3: "带来真正启动并与机器人互动的用户。",
    t4: "小程序增长",
    d4: "获取首批用户，或扩展已有受众。",
    t5: "效果类投放",
    d5: "按 CPM 采买并跟踪转化，读取每结果成本而非仅每次展示成本。",
    t6: "加密、游戏、金融科技",
    d6: "Telegram 与 TON 受众聚集的垂直领域。",
  },
  why: {
    title: "为什么选择 AdsKinz",
    sub: "具体承诺，而不是功能清单。",
    t1: "反作弊保护",
    d1: "无效展示在计费前被过滤，只为真实展示付费。",
    t2: "快速上线",
    d2: "余额充值后，从注册到投放不到 5 分钟。",
    t3: "灵活格式",
    d3: "同一素材可在多种库存格式中复用。",
    t4: "精准定向",
    d4: "当前按语言定向，后续在数据充分时支持国家定向。",
    t5: "100% 原生库存",
    d5: "所有展位均在 Telegram 内，广告不会离开生态。",
    t6: "透明定价",
    d6: "所见 CPM 即所付 CPM，无隐藏费用。",
  },
  spec: {
    title: "格式技术规格",
    sub: "面向投入预算前需要技术细节的广告主。",
    format: "格式",
    type: "类型",
    custom: "可自定义项",
    targeting: "可用定向",
    strategy: "出价策略",
    nativePost: "原生帖子",
    interstitial: "插屏",
    pop: "弹出插屏",
    typeNative: "在频道信息流中发布的图文帖子",
    typeInter: "小程序两次操作之间的全屏单元",
    typePop: "由发布者触发的非阻断式浮层",
    customAll: "链接、图片、标题、文案、按钮文字",
    customApp: "链接、图片、标题、文案、按钮文字",
    targetingVal: "语言（国家稍后）",
    strategyVal: "仅 CPM",
  },
  faq2: {
    q1: "日预算与日统计使用哪个时区？",
    a1: "全部使用 UTC+0，日预算与统计在 00:00 UTC 重置。",
    q2: "同一活动内可测试多少个素材？",
    a2: "每个活动最多 5 个素材，均匀轮播直到其中一个明显胜出。",
    q3: "系统如何检测并过滤作弊流量？",
    a3: "对展示与点击进行异常评分，被标记的展位进入人工复核隔离，相关展示不计费。",
    q4: "用户完整观看广告后能否回传转化事件？",
    a4: "可以。小程序插屏格式可通过 Kinz-ID SDK 回传完成事件，供转化跟踪读取。",
  },
};

export const landing = {
  en: { l: en },
  fr: { l: fr },
  ru: { l: ru },
  zh: { l: zh },
};
