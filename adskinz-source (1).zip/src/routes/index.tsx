import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Trans, useTranslation } from "react-i18next";
import heroMegaphone from "@/assets/hero-megaphone.png.asset.json";
import monetizeCreator from "@/assets/monetize-creator.png.asset.json";
import notifyBell from "@/assets/notify-bell.png.asset.json";
import telegramApps from "@/assets/telegram-apps.png.asset.json";
import p1 from "@/assets/person-1.jpg.asset.json";
import p2 from "@/assets/person-2.jpg.asset.json";
import p3 from "@/assets/person-3.jpg.asset.json";
import p4 from "@/assets/person-4.jpg.asset.json";
import p5 from "@/assets/person-5.jpg.asset.json";
import p6 from "@/assets/person-6.jpg.asset.json";
import p7 from "@/assets/person-7.jpg.asset.json";
import { LanguageSelect, ThemeToggle } from "@/components/controls";
import { Logo } from "@/components/dashboard-shell";
import {
  IconApp,
  IconChannel,
  IconCheck,
  IconGlobe,
  IconMegaphone,
  IconShield,
  IconSparkle,
  IconTrend,
  IconWallet,
} from "@/components/icons";
import { UsdtMark } from "@/components/usdt";
import { testimonialNames } from "@/lib/i18n-landing2";
import { faqJsonLd } from "@/lib/i18n-faq";

const SUPPORT_EMAIL = "hello@adskinz.me";
const SUPPORT_BOT = "https://t.me/helpadskinzbot";
const SUPPORT_CHANNEL = "https://t.me/adskinz";

const SITE_URL = "https://ad-seamless-flow.lovable.app";
const TITLE = "AdsKinz — Monetize Telegram channels & Mini Apps";
const DESCRIPTION =
  "Native Telegram advertising: monetize channels, bots and Mini Apps in USDT, or advertise your business from a $1.70 CPM. Payouts from 50 USDT on TRC20 and TON.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      {
        name: "keywords",
        content:
          "Telegram ads, monetize Telegram channel, Telegram Mini App ads, USDT payouts, native advertising, CPM, TRC20, TON",
      },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "AdsKinz" },
      { property: "og:url", content: SITE_URL },
      { property: "og:title", content: TITLE },
      {
        property: "og:description",
        content: "Native ads inside Telegram. Publishers earn USDT, advertisers reach engaged users from a $1.70 CPM.",
      },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: TITLE },
      {
        name: "twitter:description",
        content: "Native ads inside Telegram. Publishers earn USDT, advertisers reach engaged users from a $1.70 CPM.",
      },
    ],
    links: [{ rel: "canonical", href: SITE_URL }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Organization",
              name: "AdsKinz",
              url: SITE_URL,
              email: SUPPORT_EMAIL,
              sameAs: [SUPPORT_BOT],
              description: DESCRIPTION,
            },
            {
              "@type": "WebSite",
              name: "AdsKinz",
              url: SITE_URL,
              inLanguage: ["en", "fr", "ru", "zh"],
            },
            {
              "@type": "FAQPage",
              mainEntity: faqJsonLd.map((item) => ({
                "@type": "Question",
                name: item.q,
                acceptedAnswer: { "@type": "Answer", text: item.a },
              })),
            },
          ],
        }),
      },
    ],
  }),
  component: Landing,
});


/* ------------------------------------------------------------------ nav */

function Nav() {
  const { t } = useTranslation();
  const links = [
    { href: "#monetize", label: t("nav.publishers") },
    { href: "#advertise", label: t("nav.advertisers") },
    { href: "#money", label: t("x.money.title") },
    { href: "#faq", label: t("nav.docs") },
  ];
  return (
    <header className="sticky top-0 z-30 border-b border-seam bg-ink/85 backdrop-blur-xl">
      <div className="mx-auto flex min-h-16 max-w-6xl flex-wrap items-center gap-4 px-4 py-3">
        <Logo />
        <nav className="hidden items-center gap-6 text-sm font-semibold text-paper-dim lg:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="transition-colors hover:text-paper">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="ml-auto flex items-center gap-2">
          <LanguageSelect compact />
          <ThemeToggle />
          <Link
            to="/traffic"
            className="hidden min-h-9 items-center rounded-xl border border-seam px-3 text-sm font-semibold sm:inline-flex"
          >
            {t("common.login")}
          </Link>
          <Link
            to="/traffic/campaigns/new"
            className="inline-flex min-h-11 items-center rounded-xl bg-signal px-4 text-sm font-bold text-white transition-all hover:brightness-110"
          >
            {t("common.launchCampaign")}
          </Link>
        </div>
      </div>
    </header>
  );
}

/* -------------------------------------------------------------- helpers */

function SectionHead({ tag, title, sub, tone = "signal" }: { tag?: string; title: string; sub?: string; tone?: "signal" | "bounty" }) {
  return (
    <div className="max-w-2xl">
      {tag && (
        <span
          className={`inline-flex items-center gap-2 rounded-full border border-seam px-3 py-1 text-[11px] font-bold tracking-[0.14em] uppercase ${
            tone === "bounty" ? "text-bounty" : "text-signal"
          }`}
        >
          <IconSparkle className="size-3.5" />
          {tag}
        </span>
      )}
      <h2 className="mt-4 font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{title}</h2>
      {sub && <p className="mt-3 text-base leading-relaxed text-paper-dim">{sub}</p>}
    </div>
  );
}

function Bullet({ children, tone = "signal" }: { children: string; tone?: "signal" | "bounty" }) {
  return (
    <li className="flex gap-3">
      <span
        className={`mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-full ${
          tone === "bounty" ? "bg-bounty-soft text-bounty" : "bg-signal-soft text-signal"
        }`}
      >
        <IconCheck className="size-3.5" />
      </span>
      <span className="text-sm leading-relaxed text-paper-dim">{children}</span>
    </li>
  );
}

function TelegramMock() {
  const { t } = useTranslation();
  const bubble = "rounded-2xl border border-seam bg-panel px-4 py-3 text-sm leading-relaxed";
  return (
    <div className="glass hero-halo w-full space-y-3 p-4">
      <div className="flex items-center gap-3 pb-1">
        <div className="grad-avatar num flex size-10 items-center justify-center rounded-full text-xs font-bold">CS</div>
        <div>
          <p className="text-sm font-bold">{t("landing.mock.channel")}</p>
          <p className="num text-xs text-paper-dim">{t("landing.mock.subs")}</p>
        </div>
      </div>
      <p className={bubble}>{t("landing.mock.msg1")}</p>
      <div className={bubble}>
        <div className="flex items-start gap-2">
          <p className="flex-1">{t("landing.mock.msg2")}</p>
          <span className="animate-ad-reveal rounded-md border border-seam px-1.5 py-0.5 text-[10px] font-semibold text-paper-dim">
            {t("landing.mock.adTag")}
          </span>
        </div>
        <div className="mt-3 rounded-xl border border-seam py-2 text-center text-xs font-bold text-signal">
          {t("landing.mock.cta")}
        </div>
      </div>
      <p className={bubble}>{t("landing.mock.msg3")}</p>
    </div>
  );
}

/* ------------------------------------------------------------- sections */

function Hero() {
  const { t } = useTranslation();
  const kpis = [
    { v: "180M+", l: t("x.kpi.imp") },
    { v: "2,400+", l: t("x.kpi.chan") },
    { v: "610+", l: t("x.kpi.apps") },
    { v: "$1.9M", l: t("x.kpi.paid") },
    { v: "$1.70", l: t("x.kpi.cpm") },
  ];
  return (
    <section className="relative overflow-hidden">
      <div className="grid-veil pointer-events-none absolute inset-0" aria-hidden />
      <span className="orb top-[-120px] left-[-80px] size-[360px] bg-signal" aria-hidden />
      <span className="orb top-[120px] right-[-100px] size-[320px] bg-bounty" aria-hidden />

      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 pt-14 pb-12 lg:grid-cols-[1.05fr_0.95fr] lg:pt-20">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-seam bg-panel/70 px-3 py-1.5 text-[11px] font-bold tracking-[0.14em] text-signal uppercase backdrop-blur">
            <IconSparkle className="size-3.5" />
            {t("x.hero.badge")}
          </span>
          <h1 className="mt-5 font-display text-4xl leading-[1.05] font-extrabold tracking-tight sm:text-5xl xl:text-6xl">
            {t("x.hero.t1")} <span className="grad-text">{t("x.hero.accent")}</span> {t("x.hero.t2")}
          </h1>
          <p className="mt-5 max-w-xl text-base leading-relaxed text-paper-dim sm:text-lg">{t("x.hero.sub")}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/traffic/campaigns/new"
              className="inline-flex min-h-12 items-center justify-center rounded-xl bg-signal px-6 text-sm font-bold text-white transition-all hover:brightness-110"
            >
              {t("x.hero.ctaAdv")}
            </Link>
            <Link
              to="/partner/channels"
              className="inline-flex min-h-12 items-center justify-center rounded-xl border border-seam bg-panel/60 px-6 text-sm font-bold backdrop-blur transition-colors hover:bg-panel"
            >
              {t("x.hero.ctaPub")}
            </Link>
          </div>
          <p className="num mt-4 flex items-center gap-2 text-xs text-paper-dim">
            <UsdtMark size={14} />
            {t("x.hero.note")}
          </p>
        </div>

        <div className="relative">
          <img
            src={heroMegaphone.url}
            alt="AdsKinz native advertising"
            width={520}
            height={520}
            fetchPriority="high"
            decoding="async"
            className="float-slow mx-auto w-full max-w-[460px] drop-shadow-2xl"
          />
          <div className="mx-auto -mt-6 w-full max-w-sm sm:-mt-10">
            <TelegramMock />
          </div>
        </div>
      </div>

      <div className="relative mx-auto max-w-6xl px-4 pb-14">
        <div className="glass grid grid-cols-2 gap-px overflow-hidden bg-seam sm:grid-cols-5">
          {kpis.map((k) => (
            <div key={k.l} className="bg-panel/70 px-4 py-5 text-center">
              <p className="num font-display text-2xl font-extrabold">{k.v}</p>
              <p className="mt-1 text-[11px] font-semibold text-paper-dim">{k.l}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Marquee() {
  const { t } = useTranslation();
  const words = [
    t("l.pillars.native"),
    t("l.pillars.targeting"),
    t("l.pillars.fraud"),
    "USDT",
    "TON",
    "TRC20",
    t("x.kpi.cpm") + " $1.70",
    "Kinz-ID SDK",
  ];
  const row = [...words, ...words];
  return (
    <div className="overflow-hidden border-y border-seam bg-panel/40 py-3">
      <div className="marquee-track flex gap-8 whitespace-nowrap">
        {row.map((w, i) => (
          <span key={`${w}-${i}`} className="flex items-center gap-8 text-xs font-bold tracking-[0.18em] text-paper-dim uppercase">
            {w}
            <span className="size-1.5 rounded-full bg-signal" aria-hidden />
          </span>
        ))}
      </div>
    </div>
  );
}

function Monetize() {
  const { t } = useTranslation();
  const cards = [
    { i: <IconChannel className="text-signal" />, t: t("x.monet.c1t"), d: t("x.monet.c1d") },
    { i: <IconApp className="text-signal" />, t: t("x.monet.c2t"), d: t("x.monet.c2d") },
    { i: <IconMegaphone className="text-signal" />, t: t("x.monet.c3t"), d: t("x.monet.c3d") },
  ];
  return (
    <section id="monetize" className="mx-auto max-w-6xl px-4 py-20">
      <div className="grid items-center gap-10 lg:grid-cols-2">
        <div>
          <SectionHead tag={t("x.monet.tag")} title={t("x.monet.title")} sub={t("x.monet.sub")} tone="bounty" />
          <ul className="mt-7 space-y-3">
            {[t("x.monet.b1"), t("x.monet.b2"), t("x.monet.b3"), t("x.monet.b4")].map((b) => (
              <Bullet key={b} tone="bounty">
                {b}
              </Bullet>
            ))}
          </ul>
          <Link
            to="/partner/channels"
            className="mt-8 inline-flex min-h-12 items-center rounded-xl bg-bounty px-6 text-sm font-bold text-ink transition-all hover:brightness-110"
          >
            {t("x.monet.cta")}
          </Link>
        </div>
        <img
          src={monetizeCreator.url}
          alt={t("x.monet.title")}
          width={720}
          height={640}
          loading="lazy"
          decoding="async"
          className="float-slower mx-auto w-full max-w-[520px]"
        />
      </div>

      <div className="mt-14 grid gap-4 md:grid-cols-3">
        {cards.map((c) => (
          <article key={c.t} className="glass lift p-6">
            <span className="glass-2 inline-flex size-11 items-center justify-center">{c.i}</span>
            <h3 className="mt-4 font-display text-lg font-bold">{c.t}</h3>
            <p className="mt-2 text-sm leading-relaxed text-paper-dim">{c.d}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

function Advertise() {
  const { t } = useTranslation();
  return (
    <section id="advertise" className="relative overflow-hidden py-20">
      <span className="orb top-10 left-1/3 size-[320px] bg-signal" aria-hidden />
      <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 lg:grid-cols-2">
        <img
          src={telegramApps.url}
          alt={t("x.adv.title")}
          width={520}
          height={720}
          loading="lazy"
          decoding="async"
          className="float-slow mx-auto w-full max-w-[380px] lg:order-first"
        />
        <div>
          <SectionHead tag={t("x.adv.tag")} title={t("x.adv.title")} sub={t("x.adv.sub")} />
          <ul className="mt-7 space-y-3">
            {[t("x.adv.b1"), t("x.adv.b2"), t("x.adv.b3"), t("x.adv.b4")].map((b) => (
              <Bullet key={b}>{b}</Bullet>
            ))}
          </ul>
          <Link
            to="/traffic/campaigns/new"
            className="mt-8 inline-flex min-h-12 items-center rounded-xl bg-signal px-6 text-sm font-bold text-white transition-all hover:brightness-110"
          >
            {t("x.adv.cta")}
          </Link>
        </div>
      </div>
    </section>
  );
}

function MoneyRails() {
  const { t } = useTranslation();
  return (
    <section id="money" className="mx-auto max-w-6xl px-4 py-20">
      <SectionHead title={t("x.money.title")} sub={t("x.money.sub")} />
      <div className="mt-10 grid gap-4 lg:grid-cols-3">
        <article className="glass lift space-y-5 p-6">
          <div className="flex items-center gap-3">
            <span className="glass-2 inline-flex size-11 items-center justify-center">
              <IconWallet className="text-signal" />
            </span>
            <h3 className="font-display text-lg font-bold">{t("x.money.depT")}</h3>
          </div>
          <div className="glass-2 p-4">
            <p className="flex items-center gap-2 text-sm font-bold">
              <UsdtMark size={16} />
              {t("x.money.depCrypto")}
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{t("x.money.depCryptoD")}</p>
          </div>
          <div className="glass-2 p-4">
            <p className="text-sm font-bold">{t("x.money.depFiat")}</p>
            <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{t("x.money.depFiatD")}</p>
          </div>
        </article>

        <article className="glass lift space-y-5 p-6">
          <div className="flex items-center gap-3">
            <span className="glass-2 inline-flex size-11 items-center justify-center">
              <IconTrend className="text-bounty" />
            </span>
            <h3 className="font-display text-lg font-bold">{t("x.money.wdT")}</h3>
          </div>
          <div className="glass-2 p-4">
            <p className="num flex items-center gap-2 text-sm font-bold text-bounty">
              <UsdtMark size={16} />
              {t("x.money.wdMin")}
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{t("x.money.wdMinD")}</p>
          </div>
          <div className="glass-2 p-4">
            <p className="text-sm font-bold">{t("x.money.wdNet")}</p>
            <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{t("x.money.wdNetD")}</p>
          </div>
        </article>

        <article className="glass lift flex flex-col justify-between gap-5 p-6">
          <div className="flex items-center gap-3">
            <span className="glass-2 inline-flex size-11 items-center justify-center">
              <IconShield className="text-success" />
            </span>
            <h3 className="font-display text-lg font-bold">{t("x.money.cpmT")}</h3>
          </div>
          <p className="num font-display text-5xl font-extrabold text-signal">{t("x.money.floor")}</p>
          <p className="text-sm leading-relaxed text-paper-dim">{t("x.money.cpmD")}</p>
        </article>
      </div>
    </section>
  );
}

function Testimonials() {
  const { t } = useTranslation();
  const photos = [p1, p2, p3, p4, p5, p6, p7];
  return (
    <section className="mx-auto max-w-6xl px-4 py-20">
      <SectionHead title={t("x.test.title")} sub={t("x.test.sub")} tone="bounty" />
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {photos.map((photo, i) => (
          <figure key={testimonialNames[i]} className="glass lift flex flex-col gap-4 p-6">
            <blockquote className="border-l-2 border-signal pl-4 text-sm leading-relaxed text-paper-dim">
              “{t(`x.test.items.${i}.q`)}”
            </blockquote>
            <figcaption className="mt-auto flex items-center gap-3">
              <img
                src={photo.url}
                alt={testimonialNames[i]}
                width={44}
                height={44}
                loading="lazy"
                decoding="async"
                className="size-11 shrink-0 rounded-full object-cover"
              />
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">{testimonialNames[i]}</p>
                <p className="truncate text-xs text-paper-dim">{t(`x.test.items.${i}.r`)}</p>
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

function Support() {
  const { t } = useTranslation();
  return (
    <section id="support" className="mx-auto max-w-6xl px-4 py-20">
      <div className="glass grid items-center gap-8 p-6 sm:p-10 lg:grid-cols-[0.8fr_1.2fr]">
        <img
          src={notifyBell.url}
          alt={t("x.support.title")}
          width={420}
          height={420}
          loading="lazy"
          decoding="async"
          className="float-slow mx-auto w-full max-w-[260px]"
        />
        <div>
          <SectionHead title={t("x.support.title")} sub={t("x.support.sub")} />
          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            <a href={`mailto:${SUPPORT_EMAIL}`} className="glass-2 lift block p-5">
              <p className="flex items-center gap-2 text-sm font-bold">
                <IconGlobe className="size-4 text-signal" />
                {t("x.support.mailT")}
              </p>
              <p className="num mt-2 text-sm font-bold text-signal">{SUPPORT_EMAIL}</p>
              <p className="mt-1.5 text-xs leading-relaxed text-paper-dim">{t("x.support.mailD")}</p>
            </a>
            <a href={SUPPORT_BOT} target="_blank" rel="noreferrer" className="glass-2 lift block p-5">
              <p className="flex items-center gap-2 text-sm font-bold">
                <IconChannel className="size-4 text-signal" />
                {t("x.support.botT")}
              </p>
              <p className="num mt-2 text-sm font-bold text-signal">t.me/helpadskinzbot</p>
              <p className="mt-1.5 text-xs leading-relaxed text-paper-dim">{t("x.support.botD")}</p>
            </a>
          </div>
          <p className="mt-4 text-xs text-paper-dim">{t("x.support.hours")}</p>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  const { t } = useTranslation();
  return (
    <footer className="border-t border-seam bg-panel/40">
      <div className="mx-auto max-w-6xl px-4 py-14">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-paper-dim">{t("x.foot.blurb")}</p>
            <p className="num mt-4 flex items-center gap-2 text-xs text-paper-dim">
              <UsdtMark size={14} />
              TRC20 · TON · BNB
            </p>
          </div>
          <div>
            <p className="text-xs font-bold tracking-[0.14em] text-paper uppercase">{t("x.foot.product")}</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper-dim">
              <li>
                <a href="#monetize" className="hover:text-paper">
                  {t("nav.publishers")}
                </a>
              </li>
              <li>
                <a href="#advertise" className="hover:text-paper">
                  {t("nav.advertisers")}
                </a>
              </li>
              <li>
                <a href="#money" className="hover:text-paper">
                  {t("x.money.title")}
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-paper">
                  FAQ
                </a>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xs font-bold tracking-[0.14em] text-paper uppercase">{t("x.foot.company")}</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper-dim">
              <li>
                <Link to="/traffic" className="hover:text-paper">
                  traffic.adskinz.io
                </Link>
              </li>
              <li>
                <Link to="/partner" className="hover:text-paper">
                  partner.adskinz.io
                </Link>
              </li>
              <li>{t("x.foot.powered")}</li>
              <li>{t("x.foot.created")}</li>
            </ul>
          </div>
          <div>
            <p className="text-xs font-bold tracking-[0.14em] text-paper uppercase">{t("x.foot.support")}</p>
            <ul className="mt-4 space-y-2.5 text-sm text-paper-dim">
              <li>
                <a href={`mailto:${SUPPORT_EMAIL}`} className="hover:text-paper">
                  {SUPPORT_EMAIL}
                </a>
              </li>
              <li>
                <a href={SUPPORT_BOT} target="_blank" rel="noreferrer" className="hover:text-paper">
                  t.me/helpadskinzbot
                </a>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-seam pt-6 text-xs text-paper-dim">
          <p>{t("x.foot.rights")}</p>
          <p className="font-semibold text-signal">{t("x.foot.powered")}</p>
          <p className="font-semibold text-bounty">{t("x.foot.created")}</p>
        </div>
      </div>
    </footer>
  );
}


/* ------------------------------------------------------- CTA + long FAQ */

function CtaBand() {
  const { t } = useTranslation();
  return (
    <section id="start" className="mx-auto max-w-6xl px-4 py-20">
      <SectionHead tag={t("q.cta.tag")} title={t("q.cta.title")} sub={t("q.cta.sub")} />
      <div className="mt-10 grid gap-4 lg:grid-cols-3">
        <article className="glass lift flex flex-col p-6">
          <span className="text-xs font-bold tracking-[0.16em] text-signal uppercase">{t("q.cta.advTag")}</span>
          <h3 className="mt-3 font-display text-xl font-bold">{t("q.cta.advTitle")}</h3>
          <p className="mt-2 flex-1 text-sm leading-relaxed text-paper-dim">{t("q.cta.advDesc")}</p>
          <Link
            to="/traffic/campaigns/new"
            className="mt-6 inline-flex min-h-12 items-center justify-center rounded-xl bg-signal px-5 text-sm font-bold text-white transition-all hover:brightness-110"
          >
            {t("q.cta.advBtn")}
          </Link>
          <Link to="/traffic/deposits" className="mt-3 inline-flex min-h-10 items-center justify-center text-xs font-semibold text-paper-dim hover:text-paper">
            {t("q.cta.advAlt")}
          </Link>
        </article>

        <article className="glass lift flex flex-col p-6">
          <span className="text-xs font-bold tracking-[0.16em] text-bounty uppercase">{t("q.cta.pubTag")}</span>
          <h3 className="mt-3 font-display text-xl font-bold">{t("q.cta.pubTitle")}</h3>
          <p className="mt-2 flex-1 text-sm leading-relaxed text-paper-dim">{t("q.cta.pubDesc")}</p>
          <Link
            to="/partner/channels"
            className="mt-6 inline-flex min-h-12 items-center justify-center rounded-xl bg-bounty px-5 text-sm font-bold text-ink transition-all hover:brightness-110"
          >
            {t("q.cta.pubBtn")}
          </Link>
          <Link to="/partner/withdrawals" className="mt-3 inline-flex min-h-10 items-center justify-center text-xs font-semibold text-paper-dim hover:text-paper">
            {t("q.cta.pubAlt")}
          </Link>
        </article>

        <article className="glass lift flex flex-col p-6">
          <span className="glass-2 inline-flex size-11 items-center justify-center">
            <IconChannel className="text-signal" />
          </span>
          <h3 className="mt-4 font-display text-xl font-bold">{t("q.cta.tgTitle")}</h3>
          <p className="mt-2 flex-1 text-sm leading-relaxed text-paper-dim">{t("q.cta.tgDesc")}</p>
          <a
            href={SUPPORT_BOT}
            target="_blank"
            rel="noreferrer"
            className="mt-6 inline-flex min-h-12 items-center justify-center rounded-xl border border-seam bg-panel/60 px-5 text-sm font-bold transition-colors hover:bg-panel"
          >
            {t("q.cta.tgBot")}
          </a>
          <a
            href={SUPPORT_CHANNEL}
            target="_blank"
            rel="noreferrer"
            className="mt-3 inline-flex min-h-10 items-center justify-center text-xs font-semibold text-paper-dim hover:text-paper"
          >
            {t("q.cta.tgChannel")}
          </a>
        </article>
      </div>
    </section>
  );
}

function FaqSection() {
  const { t } = useTranslation();
  const groups = t("q.faq.groups", { returnObjects: true }) as { label: string; items: { q: string; a: string }[] }[];
  const legacy = [
    ...[1, 2, 3, 4, 5].map((n) => ({ q: t(`landing.faq.q${n}`), a: t(`landing.faq.a${n}`) })),
    ...[1, 2, 3, 4].map((n) => ({ q: t(`l.faq2.q${n}`), a: t(`l.faq2.a${n}`) })),
  ];
  const all = [...groups, { label: t("landing.faq.title"), items: legacy }];
  const [tab, setTab] = useState(-1);
  const shown = tab === -1 ? all.flatMap((g) => g.items) : (all[tab]?.items ?? []);

  return (
    <section id="faq" className="mx-auto max-w-4xl px-4 py-20">
      <SectionHead tag={t("q.faq.tag")} title={t("q.faq.title")} sub={t("q.faq.sub")} />

      <div className="mt-8 flex flex-wrap gap-2">
        {[{ label: t("q.faq.all") }, ...all].map((g, i) => {
          const idx = i - 1;
          const active = tab === idx;
          return (
            <button
              key={g.label}
              onClick={() => setTab(idx)}
              aria-pressed={active}
              className={`min-h-10 rounded-xl border px-4 text-xs font-bold transition-colors ${
                active ? "border-signal bg-signal-soft text-signal" : "border-seam text-paper-dim hover:text-paper"
              }`}
            >
              {g.label}
            </button>
          );
        })}
      </div>

      <div className="mt-8 divide-y divide-seam border-y border-seam">
        {shown.map((f) => (
          <details key={f.q} className="group py-5">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-base font-bold">
              {f.q}
              <span className="text-signal transition-transform group-open:rotate-45" aria-hidden>
                +
              </span>
            </summary>
            <p className="mt-2 text-sm leading-relaxed text-paper-dim">
              <Trans>{f.a}</Trans>
            </p>
          </details>
        ))}
      </div>

      <div className="glass mt-8 flex flex-wrap items-center justify-between gap-4 p-5">
        <p className="text-sm font-semibold">{t("q.faq.more")}</p>
        <a
          href={SUPPORT_BOT}
          target="_blank"
          rel="noreferrer"
          className="inline-flex min-h-11 items-center rounded-xl bg-signal px-5 text-sm font-bold text-white transition-all hover:brightness-110"
        >
          {t("q.faq.moreBtn")}
        </a>
      </div>
    </section>
  );
}

/* ----------------------------------------------------------------- page */

function Landing() {
  const { t } = useTranslation();

  const formats = [
    {
      tag: t("landing.formats.channel"),
      icon: <IconChannel className="text-signal" />,
      title: t("landing.formats.nativeTitle"),
      desc: t("landing.formats.nativeDesc"),
      s1: [t("landing.formats.statCpm"), "$1.70"],
      s2: [t("landing.formats.statMaxPerDay"), "3"],
    },
    {
      tag: t("landing.formats.miniapp"),
      icon: <IconApp className="text-signal" />,
      title: t("landing.formats.interstitialTitle"),
      desc: t("landing.formats.interstitialDesc"),
      s1: [t("landing.formats.statIntegration"), t("landing.formats.statIntegrationValue")],
      s2: [t("landing.formats.statSetup"), t("landing.formats.statSetupValue")],
    },
    {
      tag: t("landing.formats.miniapp"),
      icon: <IconApp className="text-signal" />,
      title: t("landing.formats.popTitle"),
      desc: t("landing.formats.popDesc"),
      s1: [t("landing.formats.statIntegration"), t("landing.formats.statIntegrationValue")],
      s2: [t("landing.formats.statSetup"), t("landing.formats.statSetupValue")],
    },
  ];

  const steps = [1, 2, 3, 4].map((n) => ({ n, title: t(`landing.how.s${n}t`), desc: t(`landing.how.s${n}d`) }));
  const useCases = [1, 2, 3, 4, 5, 6].map((n) => ({ t: t(`l.use.t${n}`), d: t(`l.use.d${n}`) }));
  const why = [1, 2, 3, 4, 5, 6].map((n) => ({ t: t(`l.why.t${n}`), d: t(`l.why.d${n}`) }));
  const specRows = [
    { f: t("l.spec.nativePost"), ty: t("l.spec.typeNative"), c: t("l.spec.customAll") },
    { f: t("l.spec.interstitial"), ty: t("l.spec.typeInter"), c: t("l.spec.customApp") },
    { f: t("l.spec.pop"), ty: t("l.spec.typePop"), c: t("l.spec.customApp") },
  ];

  return (
    <div className="min-h-screen bg-ink">
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <Monetize />
        <Advertise />

        {/* Formats */}
        <section id="formats" className="mx-auto max-w-6xl px-4 py-20">
          <SectionHead title={t("landing.formats.title")} sub={t("landing.formats.subtitle")} />
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {formats.map((f) => (
              <article key={f.title} className="glass lift flex flex-col p-6">
                <div className="flex items-center gap-2">
                  {f.icon}
                  <span className="rounded-md border border-seam px-2 py-0.5 text-[11px] font-semibold text-paper-dim">{f.tag}</span>
                </div>
                <h3 className="mt-4 font-display text-xl font-bold">{f.title}</h3>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-paper-dim">{f.desc}</p>
                <div className="mt-5 grid grid-cols-2 gap-4 border-t border-seam pt-4">
                  {[f.s1, f.s2].map(([label, value]) => (
                    <div key={label}>
                      <p className="text-[11px] font-semibold text-paper-dim">{label}</p>
                      <p className="num mt-0.5 text-sm font-bold">{value}</p>
                    </div>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>

        <MoneyRails />

        {/* Use cases */}
        <section className="mx-auto max-w-6xl px-4 py-20">
          <SectionHead title={t("l.use.title")} sub={t("l.use.sub")} />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {useCases.map((c) => (
              <article key={c.t} className="glass lift p-6">
                <IconSparkle className="text-signal" />
                <h3 className="mt-4 text-base font-bold">{c.t}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{c.d}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Why */}
        <section className="mx-auto max-w-6xl px-4 py-20">
          <SectionHead title={t("l.why.title")} sub={t("l.why.sub")} tone="bounty" />
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {why.map((c) => (
              <article key={c.t} className="glass lift p-6">
                <IconShield className="text-bounty" />
                <h3 className="mt-4 text-base font-bold">{c.t}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{c.d}</p>
              </article>
            ))}
          </div>
        </section>

        {/* Spec table */}
        <section className="mx-auto max-w-6xl px-4 py-20">
          <SectionHead title={t("l.spec.title")} sub={t("l.spec.sub")} />
          <div className="glass mt-10 overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="text-xs font-semibold text-paper-dim uppercase">
                <tr className="border-b border-seam">
                  <th scope="col" className="px-4 py-3">{t("l.spec.format")}</th>
                  <th scope="col" className="px-4 py-3">{t("l.spec.type")}</th>
                  <th scope="col" className="px-4 py-3">{t("l.spec.custom")}</th>
                  <th scope="col" className="px-4 py-3">{t("l.spec.targeting")}</th>
                  <th scope="col" className="px-4 py-3">{t("l.spec.strategy")}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-seam">
                {specRows.map((r) => (
                  <tr key={r.f}>
                    <th scope="row" className="px-4 py-4 font-bold">{r.f}</th>
                    <td className="px-4 py-4 text-paper-dim">{r.ty}</td>
                    <td className="px-4 py-4 text-paper-dim">{r.c}</td>
                    <td className="px-4 py-4 text-paper-dim">{t("l.spec.targetingVal")}</td>
                    <td className="num px-4 py-4 font-bold text-bounty">{t("l.spec.strategyVal")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        {/* How it works */}
        <section className="mx-auto max-w-6xl px-4 py-20">
          <SectionHead title={t("landing.how.title")} />
          <div className="mt-10 grid gap-6 md:grid-cols-4">
            {steps.map((s) => (
              <div key={s.n} className="glass-2 p-5">
                <div className="num flex size-10 items-center justify-center rounded-full border-2 border-signal text-sm font-bold text-signal">
                  {s.n}
                </div>
                <h3 className="mt-4 text-base font-bold">{s.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-paper-dim">{s.desc}</p>
              </div>
            ))}
          </div>
        </section>

        <Testimonials />

        {/* Dual audience */}
        <section id="audience" className="mx-auto max-w-6xl px-4 py-20">
          <div className="grid gap-4 md:grid-cols-2">
            <article className="glass lift flex flex-col p-6">
              <span className="text-xs font-bold tracking-[0.16em] text-signal uppercase">{t("landing.audience.advTitle")}</span>
              <h3 className="mt-3 font-display text-2xl font-extrabold">{t("landing.audience.advSub")}</h3>
              <ul className="mt-5 flex-1 space-y-3">
                {["advB1", "advB2", "advB3"].map((k) => (
                  <Bullet key={k}>{t(`landing.audience.${k}`)}</Bullet>
                ))}
              </ul>
              <Link
                to="/traffic/campaigns/new"
                className="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-xl bg-signal text-sm font-bold text-white"
              >
                {t("common.launchCampaign")}
              </Link>
            </article>
            <article className="glass lift flex flex-col p-6">
              <span className="text-xs font-bold tracking-[0.16em] text-bounty uppercase">{t("landing.audience.pubTitle")}</span>
              <h3 className="mt-3 font-display text-2xl font-extrabold">{t("landing.audience.pubSub")}</h3>
              <ul className="mt-5 flex-1 space-y-3">
                {["pubB1", "pubB2", "pubB3"].map((k) => (
                  <Bullet key={k} tone="bounty">
                    {t(`landing.audience.${k}`)}
                  </Bullet>
                ))}
              </ul>
              <Link
                to="/partner/channels"
                className="mt-6 inline-flex min-h-12 w-full items-center justify-center rounded-xl border border-seam text-sm font-bold"
              >
                {t("common.becomePublisher")}
              </Link>
            </article>
          </div>
        </section>

        <Support />

        <CtaBand />

        <FaqSection />

        {/* Final CTA */}
        <section className="mx-auto max-w-6xl px-4 pb-24">
          <div className="glass hero-halo relative overflow-hidden p-8 text-center sm:p-14">
            <span className="orb top-[-60px] left-1/2 size-[280px] -translate-x-1/2 bg-signal" aria-hidden />
            <div className="relative">
              <h2 className="font-display text-3xl font-extrabold tracking-tight sm:text-4xl">{t("x.cta.title")}</h2>
              <p className="mx-auto mt-3 max-w-xl text-paper-dim">{t("x.cta.sub")}</p>
              <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
                <Link
                  to="/traffic/campaigns/new"
                  className="inline-flex min-h-12 items-center justify-center rounded-xl bg-signal px-6 text-sm font-bold text-white transition-all hover:brightness-110"
                >
                  {t("x.cta.btn")}
                </Link>
                <Link
                  to="/partner/channels"
                  className="inline-flex min-h-12 items-center justify-center rounded-xl border border-seam px-6 text-sm font-bold"
                >
                  {t("x.cta.btn2")}
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
