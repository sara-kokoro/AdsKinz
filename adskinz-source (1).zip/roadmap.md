# Roadmap AdsKinz

- [ ] Landing : CTA clairs annonceurs / éditeurs (dashboards + actions Telegram)
- [ ] Landing : FAQ longue en accordéons (canal, mini app, dépôts, retraits, CPM min)
- [ ] Landing : SEO (meta, Open Graph, canonical, JSON-LD) + lazy-loading images/SVG
- [ ] Dashboard éditeur : plus d'éléments (perf par canal, revenus par pub, historique des posts)
- [ ] Ajout de canal : détection lien privé (https://t.me/+) refusé en direct, avant validation
- [ ] Thème : noir moins profond
- [ ] Livrer le code source en zip
